# -*- coding: utf-8 -*-
"""Utilities for recovering JSON from LLM responses."""

from __future__ import annotations

import json
import re
from typing import Any, Optional


def _try_json_loads(text: str) -> Optional[Any]:
    try:
        return json.loads(text)
    except (TypeError, json.JSONDecodeError):
        return None


def _extract_json_block(text: str) -> Optional[str]:
    """Extract the first balanced JSON object or array from mixed text."""

    start_indexes = [index for index, char in enumerate(text) if char in "{["]
    for start in start_indexes:
        opening = text[start]
        closing = "}" if opening == "{" else "]"
        stack = [closing]
        in_string = False
        escape = False

        for index in range(start + 1, len(text)):
            char = text[index]
            if in_string:
                if escape:
                    escape = False
                elif char == "\\":
                    escape = True
                elif char == '"':
                    in_string = False
                continue

            if char == '"':
                in_string = True
            elif char in "{[":
                stack.append("}" if char == "{" else "]")
            elif char in "}]":
                if not stack or char != stack[-1]:
                    break
                stack.pop()
                if not stack:
                    return text[start : index + 1]

    return None


def safe_json_loads(text: str) -> Optional[Any]:
    """Parse JSON from raw model text, Markdown fences, or mixed explanation."""

    if not isinstance(text, str) or not text.strip():
        return None

    stripped = text.strip()
    direct = _try_json_loads(stripped)
    if direct is not None:
        return direct

    fence_matches = re.findall(
        r"```(?:json|JSON)?\s*(.*?)```", stripped, flags=re.DOTALL
    )
    for fenced in fence_matches:
        parsed = _try_json_loads(fenced.strip())
        if parsed is not None:
            return parsed

    block = _extract_json_block(stripped)
    if block:
        return _try_json_loads(block)

    return None


def ensure_json_result(raw_text: str, fallback: Any) -> Any:
    """Return parsed JSON if possible; otherwise return the provided fallback."""

    parsed = safe_json_loads(raw_text)
    if parsed is None:
        return fallback
    return parsed

