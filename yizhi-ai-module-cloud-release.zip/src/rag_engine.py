# -*- coding: utf-8 -*-
"""Lightweight RAG prototype based on keyword retrieval."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from .config import PROJECT_ROOT, get_settings
from .json_utils import ensure_json_result
from .llm_client import DeepSeekClient
from .schemas import clean_text


KNOWLEDGE_PATH = PROJECT_ROOT / "data" / "knowledge.json"


def _load_knowledge() -> List[Dict[str, Any]]:
    try:
        return json.loads(KNOWLEDGE_PATH.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []


def _tokenize(text: str) -> List[str]:
    """Simple mixed Chinese/English tokenizer for a tiny local prototype."""

    normalized = text.lower()
    words = re.findall(r"[a-z0-9]+|[\u4e00-\u9fff]", normalized)
    phrases = [
        phrase
        for phrase in re.split(r"[\s,，。？?！!；;、]+", normalized)
        if len(phrase) >= 2
    ]
    return words + phrases


def _score_item(query: str, query_tokens: List[str], item: Dict[str, Any]) -> int:
    haystack = " ".join(
        [
            clean_text(item.get("title")),
            clean_text(item.get("category")),
            clean_text(item.get("content")),
            clean_text(item.get("action")),
            " ".join(item.get("keywords") or []),
        ]
    ).lower()

    score = 0
    for keyword in item.get("keywords") or []:
        if keyword.lower() in query.lower():
            score += 8
        if keyword.lower() in haystack and keyword.lower() in query.lower():
            score += 4
    for token in query_tokens:
        if token in haystack:
            score += 1 if len(token) == 1 else 3
    return score


def retrieve_knowledge(query: str, top_k: int = 3) -> List[Dict[str, Any]]:
    """Return the most relevant knowledge records."""

    knowledge = _load_knowledge()
    query_tokens = _tokenize(query)
    scored = [
        (_score_item(query, query_tokens, item), item)
        for item in knowledge
    ]
    scored.sort(key=lambda pair: pair[0], reverse=True)

    results = []
    for score, item in scored[:top_k]:
        if score <= 0 and results:
            continue
        results.append(
            {
                "id": item.get("id"),
                "category": item.get("category"),
                "title": item.get("title"),
                "keywords": item.get("keywords", []),
                "content": item.get("content"),
                "action": item.get("action"),
            }
        )
    return results


def _mock_rag_answer(query: str, retrieved: List[Dict[str, Any]]) -> str:
    if not retrieved:
        return "知识库暂未找到直接匹配内容，建议记录问题并转交社区人员跟进。"

    parts = [f"{item['title']}：{item['content']} 建议：{item['action']}" for item in retrieved]
    return "根据养老知识库，" + "；".join(parts)


def generate_rag_answer(
    query: str, client: Optional[DeepSeekClient] = None, top_k: int = 3
) -> Dict[str, Any]:
    """Retrieve knowledge and generate a JSON answer."""

    try:
        normalized_top_k = int(top_k)
    except (TypeError, ValueError):
        normalized_top_k = 3
    normalized_top_k = max(1, normalized_top_k)

    retrieved = retrieve_knowledge(query, top_k=normalized_top_k)
    fallback = {
        "query": query,
        "retrieved_knowledge": retrieved,
        "answer": _mock_rag_answer(query, retrieved),
    }

    if get_settings().should_use_mock:
        return fallback

    prompt = (
        "你是智慧养老知识库助手。请只基于给定知识回答，不要输出 Markdown，"
        "不要给出确定医疗诊断，只输出 JSON，字段为 query、retrieved_knowledge、answer。"
    )
    llm = client or DeepSeekClient()
    messages = [
        {"role": "system", "content": prompt},
        {
            "role": "user",
            "content": json.dumps(
                {"query": query, "retrieved_knowledge": retrieved},
                ensure_ascii=False,
            ),
        },
    ]
    response = llm.chat_completion(messages, temperature=0.2)
    if not response["ok"]:
        return fallback

    parsed = ensure_json_result(response["content"], fallback)
    if not isinstance(parsed, dict):
        return fallback

    return {
        "query": clean_text(parsed.get("query"), query),
        "retrieved_knowledge": retrieved,
        "answer": clean_text(parsed.get("answer"), fallback["answer"]),
    }
