# -*- coding: utf-8 -*-
"""Runtime configuration for the local AI prototype.

The module reads Windows user environment variables with os.getenv. If a local
.env file exists and python-dotenv is installed, it is loaded as a convenience
for local development, but it is never required.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def _load_dotenv_if_available() -> None:
    """Load .env when python-dotenv is installed; silently skip otherwise."""

    try:
        from dotenv import load_dotenv  # type: ignore
    except Exception:
        return

    env_path = PROJECT_ROOT / ".env"
    if env_path.exists():
        load_dotenv(env_path)


def _read_timeout(default: int = 60) -> int:
    raw_value = os.getenv("TIMEOUT_SECONDS", str(default)).strip()
    try:
        timeout = int(raw_value)
    except ValueError:
        return default
    return max(timeout, 1)


@dataclass(frozen=True)
class Settings:
    """Immutable settings used by every module."""

    deepseek_api_key: Optional[str]
    deepseek_base_url: str
    deepseek_model: str
    mock_mode: str
    timeout_seconds: int

    @property
    def has_api_key(self) -> bool:
        return bool(self.deepseek_api_key and self.deepseek_api_key.strip())

    @property
    def should_use_mock(self) -> bool:
        """Resolve MOCK_MODE into the final runtime behavior."""

        mode = self.mock_mode.lower()
        if mode == "true":
            return True
        if mode == "false":
            return False
        return not self.has_api_key

    @property
    def mode_label(self) -> str:
        if self.should_use_mock:
            return "mock"
        return "deepseek-api"

    @property
    def chat_completions_url(self) -> str:
        """Build the OpenAI-compatible Chat Completions endpoint URL."""

        base_url = self.deepseek_base_url.rstrip("/")
        return f"{base_url}/chat/completions"


def get_settings() -> Settings:
    """Read environment variables every time to make demos easy to rerun."""

    _load_dotenv_if_available()
    mock_mode = os.getenv("MOCK_MODE", "auto").strip().lower()
    if mock_mode not in {"auto", "true", "false"}:
        mock_mode = "auto"

    return Settings(
        deepseek_api_key=os.getenv("DEEPSEEK_API_KEY"),
        deepseek_base_url=os.getenv(
            "DEEPSEEK_BASE_URL", "https://api.deepseek.com"
        ).strip(),
        deepseek_model=os.getenv("DEEPSEEK_MODEL", "deepseek-v4-pro").strip(),
        mock_mode=mock_mode,
        timeout_seconds=_read_timeout(),
    )


def describe_runtime_mode() -> str:
    """Return a safe mode description without exposing any secret."""

    settings = get_settings()
    if settings.mock_mode == "false" and not settings.has_api_key:
        return "MOCK_MODE=false, but DEEPSEEK_API_KEY is not readable"
    if settings.should_use_mock:
        return "mock mode"
    return f"DeepSeek API mode, model={settings.deepseek_model}"

