# -*- coding: utf-8 -*-
"""Health risk analysis using rules first, then optional LLM refinement."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

from .config import PROJECT_ROOT, get_settings
from .json_utils import ensure_json_result
from .llm_client import DeepSeekClient
from .schemas import RISK_LEVELS, WORK_ORDER_TYPES, as_bool, clean_text


PROMPT_PATH = PROJECT_ROOT / "prompts" / "health_analysis_prompt.txt"


def _load_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8")
    except OSError:
        return "请根据健康数据输出严格 JSON。"


def evaluate_health_rules(case: Dict[str, Any]) -> Dict[str, Any]:
    """Evaluate deterministic risk rules before calling any model."""

    heart_rate = float(case.get("heart_rate") or 0)
    spo2 = float(case.get("spo2") or 0)
    temperature = float(case.get("temperature") or 0)
    fall_status = clean_text(case.get("fall_status"))
    activity_status = clean_text(case.get("activity_status"))

    flags = {
        "spo2_low": 0 < spo2 < 92,
        "heart_rate_high": heart_rate > 110,
        "temperature_high": temperature >= 37.5,
        "fall_suspected": "疑似跌倒" in fall_status or "摔倒" in fall_status,
        "long_static": "长时间静止" in activity_status or "未起身" in clean_text(
            case.get("duration")
        ),
    }

    reasons = []
    if flags["fall_suspected"]:
        reasons.append("传感器提示疑似跌倒")
    if flags["long_static"]:
        reasons.append("存在长时间静止或未起身")
    if flags["spo2_low"]:
        reasons.append(f"血氧 {spo2:g}% 低于 92%")
    if flags["heart_rate_high"]:
        reasons.append(f"心率 {heart_rate:g} 次/分高于 110")
    if flags["temperature_high"]:
        reasons.append(f"体温 {temperature:g}℃ 偏高")

    if flags["fall_suspected"] and flags["long_static"]:
        risk_level = "高风险"
    elif flags["fall_suspected"] and (flags["spo2_low"] or flags["heart_rate_high"]):
        risk_level = "高风险"
    elif flags["spo2_low"] and flags["heart_rate_high"]:
        risk_level = "中风险"
    elif flags["spo2_low"] or flags["heart_rate_high"] or flags["long_static"]:
        risk_level = "中风险"
    elif flags["temperature_high"]:
        risk_level = "低风险"
    else:
        risk_level = "正常"

    need_alarm = risk_level == "高风险"
    need_work_order = risk_level in {"高风险", "中风险"}
    if risk_level == "高风险":
        work_order_type = "紧急巡检"
    elif risk_level == "中风险":
        work_order_type = "健康关注"
    elif flags["temperature_high"]:
        work_order_type = "健康关注"
        need_work_order = True
    else:
        work_order_type = "无需工单"

    return {
        "flags": flags,
        "reasons": reasons,
        "risk_level": risk_level,
        "need_alarm": need_alarm,
        "need_work_order": need_work_order,
        "work_order_type": work_order_type,
    }


def _build_rule_result(case: Dict[str, Any], rules: Dict[str, Any]) -> Dict[str, Any]:
    elder_id = clean_text(case.get("elder_id"), "UNKNOWN")
    elder_name = clean_text(case.get("elder_name"), "老人")
    location = clean_text(case.get("location"), "当前位置")
    reasons = rules["reasons"] or ["当前数据未发现明显异常"]
    risk_level = rules["risk_level"]

    if risk_level == "高风险":
        elder_reply = f"{elder_name}，请先不要着急，尽量保持不动，我们正在联系家属和社区人员。"
        family_notice = (
            f"{elder_name}在{location}出现高风险告警：{'；'.join(reasons)}。"
            "建议立即电话确认并通知社区上门查看。"
        )
        community_suggestion = "建议立即生成紧急巡检工单，联系家属并安排社区人员上门核实。"
    elif risk_level == "中风险":
        elder_reply = f"{elder_name}，我看到您的状态有些异常，请先坐下休息，慢慢呼吸。"
        family_notice = (
            f"{elder_name}存在健康关注信号：{'；'.join(reasons)}。"
            "建议尽快电话确认老人状态。"
        )
        community_suggestion = "建议生成健康关注工单，持续观察 15-30 分钟并记录处理结果。"
    elif risk_level == "低风险":
        elder_reply = f"{elder_name}，请先休息一下，多喝温水，稍后我会继续观察。"
        family_notice = f"{elder_name}出现轻微异常：{'；'.join(reasons)}，建议继续观察。"
        community_suggestion = "建议暂不升级紧急告警，可在健康关注列表中持续跟踪。"
    else:
        elder_reply = f"{elder_name}，目前数据看起来平稳，请保持正常作息。"
        family_notice = f"{elder_name}当前健康数据未发现明显异常。"
        community_suggestion = "无需生成工单，保持常规监测。"

    return {
        "elder_id": elder_id,
        "risk_level": risk_level,
        "risk_reason": "；".join(reasons),
        "elder_reply": elder_reply,
        "family_notice": family_notice,
        "community_suggestion": community_suggestion,
        "need_alarm": bool(rules["need_alarm"]),
        "need_work_order": bool(rules["need_work_order"]),
        "work_order_type": rules["work_order_type"],
    }


def _normalize_health_result(
    parsed: Dict[str, Any], fallback: Dict[str, Any]
) -> Dict[str, Any]:
    """Keep the public JSON contract stable even if model wording drifts."""

    if not isinstance(parsed, dict):
        return fallback

    result = dict(fallback)
    for key in result:
        if key in parsed:
            result[key] = parsed[key]

    if result["risk_level"] not in RISK_LEVELS:
        result["risk_level"] = fallback["risk_level"]
    if result["work_order_type"] not in WORK_ORDER_TYPES:
        result["work_order_type"] = fallback["work_order_type"]
    result["need_alarm"] = as_bool(result["need_alarm"])
    result["need_work_order"] = as_bool(result["need_work_order"])
    return result


def analyze_health_data(
    case: Dict[str, Any], client: Optional[DeepSeekClient] = None
) -> Dict[str, Any]:
    """Return fixed JSON health-analysis output for one elder event."""

    rules = evaluate_health_rules(case)
    fallback = _build_rule_result(case, rules)
    settings = get_settings()

    if settings.should_use_mock:
        return fallback

    llm = client or DeepSeekClient(settings)
    messages = [
        {"role": "system", "content": _load_prompt()},
        {
            "role": "user",
            "content": json.dumps(
                {
                    "sensor_data": case,
                    "rule_judgement": rules,
                    "required_output_fields": list(fallback.keys()),
                },
                ensure_ascii=False,
            ),
        },
    ]
    response = llm.chat_completion(messages, temperature=0.2)
    if not response["ok"]:
        fallback["risk_reason"] = (
            f"{fallback['risk_reason']}（LLM 调用失败，已使用规则分析）"
        )
        return fallback

    parsed = ensure_json_result(response["content"], fallback)
    return _normalize_health_result(parsed, fallback)

