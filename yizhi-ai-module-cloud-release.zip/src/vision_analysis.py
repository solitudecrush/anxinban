# -*- coding: utf-8 -*-
"""VLM placeholder for camera image analysis.

deepseek-v4-pro is used here as a text model in this prototype. This module is
therefore intentionally mock-only and keeps the future VLM integration point
isolated for Qwen-VL, Qwen2.5-VL, or another multimodal API.
"""

from __future__ import annotations

from typing import Any, Dict

from .schemas import VISION_TASKS, clean_text


def analyze_vision(vision_input: Dict[str, Any]) -> Dict[str, Any]:
    """Return task-specific mock VLM results with a stable JSON contract."""

    elder_id = clean_text(vision_input.get("elder_id"), "UNKNOWN")
    task = clean_text(vision_input.get("task"), "scene_description")
    if task not in VISION_TASKS:
        task = "scene_description"

    if task == "fall_detection":
        result = {
            "vision_result": "画面中疑似有人倒地，姿态异常，需要人工确认。",
            "risk_level": "高风险",
            "suggestion": "建议立即确认老人状态，并通知家属或社区人员。",
        }
    elif task == "object_search":
        result = {
            "vision_result": "已模拟检索室内画面，目标物品可能在桌面或沙发旁。",
            "risk_level": "低风险",
            "suggestion": "建议通过语音引导老人先坐稳，再由家属或摄像头继续确认位置。",
        }
    elif task == "door_visitor":
        result = {
            "vision_result": "门口抓拍到访客轮廓，当前为 mock 描述，需接入真实 VLM 后识别。",
            "risk_level": "中风险",
            "suggestion": "建议先不要远程开锁，通知家属或社区人员确认访客身份。",
        }
    else:
        result = {
            "vision_result": "当前为普通场景描述 mock，未发现明确紧急视觉风险。",
            "risk_level": "正常",
            "suggestion": "建议保持常规监测，后续接入真实 VLM 后输出更准确的场景描述。",
        }

    return {
        "elder_id": elder_id,
        "task": task,
        "vision_result": result["vision_result"],
        "risk_level": result["risk_level"],
        "suggestion": result["suggestion"],
    }


def call_future_vlm_api(_: Dict[str, Any]) -> Dict[str, Any]:
    """Reserved integration point for a real multimodal VLM provider."""

    raise NotImplementedError("VLM API integration is reserved for cloud deployment.")

