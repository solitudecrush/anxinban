# -*- coding: utf-8 -*-
"""Small DeepSeek Chat Completions client.

The client never prints or logs API keys. In mock mode it does not perform any
network request, which keeps every demo runnable on a Windows laptop.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional

import requests

from .config import Settings, get_settings


Message = Dict[str, str]


class DeepSeekClient:
    """OpenAI-compatible client wrapper for DeepSeek text models."""

    def __init__(self, settings: Optional[Settings] = None) -> None:
        self.settings = settings or get_settings()

    def chat_completion(
        self, messages: List[Message], temperature: float = 0.2
    ) -> Dict[str, Any]:
        """Call DeepSeek or return a deterministic mock response.

        Returns:
            {
                "ok": bool,
                "content": str,
                "mock": bool,
                "error": str | None,
            }
        """

        if self.settings.should_use_mock:
            return {
                "ok": True,
                "content": self._mock_completion(messages),
                "mock": True,
                "error": None,
            }

        if not self.settings.has_api_key:
            return {
                "ok": False,
                "content": "",
                "mock": False,
                "error": (
                    "MOCK_MODE=false requires DEEPSEEK_API_KEY, but the current "
                    "Python process cannot read it. Reopen PowerShell/CMD/Codex "
                    "after setting the Windows user environment variable."
                ),
            }

        headers = {
            "Authorization": f"Bearer {self.settings.deepseek_api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.settings.deepseek_model,
            "messages": messages,
            "temperature": temperature,
        }

        try:
            response = requests.post(
                self.settings.chat_completions_url,
                headers=headers,
                json=payload,
                timeout=self.settings.timeout_seconds,
            )
        except requests.RequestException as exc:
            return {
                "ok": False,
                "content": "",
                "mock": False,
                "error": f"DeepSeek API request failed: {exc}",
            }

        if response.status_code >= 400:
            return {
                "ok": False,
                "content": "",
                "mock": False,
                "error": self._format_http_error(response),
            }

        try:
            body = response.json()
            content = body["choices"][0]["message"]["content"]
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            return {
                "ok": False,
                "content": "",
                "mock": False,
                "error": f"DeepSeek API returned an unexpected response: {exc}",
            }

        return {"ok": True, "content": str(content), "mock": False, "error": None}

    @staticmethod
    def _format_http_error(response: requests.Response) -> str:
        try:
            body = response.json()
            message = body.get("error", {}).get("message") or body.get("message")
        except ValueError:
            message = response.text[:300]
        return f"DeepSeek API HTTP {response.status_code}: {message}"

    @staticmethod
    def _mock_completion(messages: List[Message]) -> str:
        """Generic JSON-shaped mock for direct client tests."""

        last_message = messages[-1]["content"] if messages else ""
        mock = {
            "mock": True,
            "message": "当前为 mock 模式，未请求 DeepSeek API。",
            "input_preview": last_message[:120],
        }
        return json.dumps(mock, ensure_ascii=False)

