# -*- coding: utf-8 -*-
"""Elder companionship chat with rule-first emergency handling."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

from .config import PROJECT_ROOT, get_settings
from .json_utils import ensure_json_result
from .llm_client import DeepSeekClient
from .schemas import CHAT_INTENTS, as_bool, clean_text


PROMPT_PATH = PROJECT_ROOT / "prompts" / "chat_prompt.txt"

EMERGENCY_KEYWORDS = [
    "救命",
    "摔倒",
    "跌倒",
    "喘不上气",
    "胸口疼",
    "胸闷",
    "不舒服",
    "头晕",
    "呼吸困难",
    "叫人",
    "打电话",
    "难受",
]


def _load_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8")
    except OSError:
        return "请用适老化、简短、温和的方式回复老人，并输出 JSON。"


def _health_signal_is_risky(recent_health: Dict[str, Any]) -> bool:
    heart_rate = float(recent_health.get("heart_rate") or 0)
    spo2 = float(recent_health.get("spo2") or 0)
    temperature = float(recent_health.get("temperature") or 0)
    return (0 < spo2 < 92) or heart_rate > 110 or temperature >= 37.5


def classify_chat_intent(message: str, recent_health: Dict[str, Any]) -> Dict[str, Any]:
    """Classify high-risk chat by rules before using the model."""

    text = message.strip()
    compact = text.replace(" ", "")
    has_emergency_keyword = any(keyword in compact for keyword in EMERGENCY_KEYWORDS)
    risky_health = _health_signal_is_risky(recent_health)

    if has_emergency_keyword or (risky_health and any(word in compact for word in ["身体", "好吗", "不适"])):
        return {
            "intent": "紧急求助",
            "need_alarm": True,
            "need_family_notify": True,
            "suggested_action": "立即联系家属或社区人员，并持续安抚老人。",
            "rule_locked": True,
        }

    if any(word in compact for word in ["水杯", "钥匙", "眼镜", "遥控器", "找不到", "在哪里"]):
        return {
            "intent": "物品查找",
            "need_alarm": False,
            "need_family_notify": False,
            "suggested_action": "调用室内摄像头或物品定位能力，帮助老人查找物品。",
            "rule_locked": False,
        }

    if any(word in compact for word in ["门口", "门锁", "开门", "关门", "访客"]):
        return {
            "intent": "设备控制",
            "need_alarm": False,
            "need_family_notify": False,
            "suggested_action": "调用门锁或门口摄像头事件，向老人播报安全确认结果。",
            "rule_locked": False,
        }

    if any(word in compact for word in ["睡不着", "吃药", "血氧", "心率", "体温", "身体"]):
        return {
            "intent": "健康咨询",
            "need_alarm": False,
            "need_family_notify": False,
            "suggested_action": "提供非诊断性质的健康建议，并提示持续不适时联系家属或医生。",
            "rule_locked": False,
        }

    if any(word in compact for word in ["女儿", "儿子", "家属", "联系"]):
        return {
            "intent": "普通陪伴",
            "need_alarm": False,
            "need_family_notify": True,
            "suggested_action": "记录联系家属请求，转给亲属 APP 或电话服务。",
            "rule_locked": False,
        }

    return {
        "intent": "普通陪伴",
        "need_alarm": False,
        "need_family_notify": False,
        "suggested_action": "继续陪伴对话，必要时引导老人表达需求。",
        "rule_locked": False,
    }


def _build_rule_reply(elder_id: str, message: str, judgement: Dict[str, Any]) -> Dict[str, Any]:
    intent = judgement["intent"]

    if intent == "紧急求助":
        reply = "我在，请先坐下或保持不动，慢慢呼吸。我会帮您联系家属和社区人员。"
    elif intent == "物品查找":
        reply = "好的，我帮您找一找。请您先坐稳，不要着急走动。"
    elif intent == "设备控制":
        reply = "我来帮您确认门口情况，请先不要开门。"
    elif intent == "健康咨询":
        reply = "我听到了。先放松休息一下，如果一直不舒服，我会建议您联系家人或医生。"
    else:
        reply = "我在陪着您。您可以慢慢说，我会认真听。"

    return {
        "elder_id": elder_id,
        "intent": intent,
        "reply": reply,
        "need_alarm": bool(judgement["need_alarm"]),
        "need_family_notify": bool(judgement["need_family_notify"]),
        "suggested_action": judgement["suggested_action"],
    }


def _normalize_chat_result(parsed: Dict[str, Any], fallback: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(parsed, dict):
        return fallback

    result = dict(fallback)
    for key in result:
        if key in parsed:
            result[key] = parsed[key]

    if result["intent"] not in CHAT_INTENTS:
        result["intent"] = fallback["intent"]
    result["need_alarm"] = as_bool(result["need_alarm"])
    result["need_family_notify"] = as_bool(result["need_family_notify"])
    return result


def chat_with_elder(
    chat_input: Dict[str, Any], client: Optional[DeepSeekClient] = None
) -> Dict[str, Any]:
    """Return fixed JSON chat output for an elder message."""

    elder_id = clean_text(chat_input.get("elder_id"), "UNKNOWN")
    message = clean_text(chat_input.get("message"))
    recent_health = chat_input.get("recent_health") or {}
    judgement = classify_chat_intent(message, recent_health)
    fallback = _build_rule_reply(elder_id, message, judgement)

    if judgement["rule_locked"] or get_settings().should_use_mock:
        return fallback

    llm = client or DeepSeekClient()
    messages = [
        {"role": "system", "content": _load_prompt()},
        {
            "role": "user",
            "content": json.dumps(
                {
                    "elder_id": elder_id,
                    "message": message,
                    "recent_health": recent_health,
                    "rule_intent_hint": judgement,
                    "required_output_fields": list(fallback.keys()),
                },
                ensure_ascii=False,
            ),
        },
    ]
    response = llm.chat_completion(messages, temperature=0.4)
    if not response["ok"]:
        return fallback

    parsed = ensure_json_result(response["content"], fallback)
    return _normalize_chat_result(parsed, fallback)

