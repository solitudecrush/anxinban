# -*- coding: utf-8 -*-
"""Shared schema field names and small normalization helpers."""

from __future__ import annotations

from typing import Any


RISK_LEVELS = {"高风险", "中风险", "低风险", "正常"}
WORK_ORDER_TYPES = {"紧急巡检", "健康关注", "设备检查", "无需工单"}
CHAT_INTENTS = {"普通陪伴", "健康咨询", "紧急求助", "物品查找", "设备控制"}
VISION_TASKS = {
    "fall_detection",
    "object_search",
    "door_visitor",
    "scene_description",
}


def as_bool(value: Any) -> bool:
    """Normalize common model outputs into a strict boolean."""

    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes", "y", "是", "需要"}
    return False


def clean_text(value: Any, default: str = "") -> str:
    """Convert an arbitrary value into a compact display string."""

    if value is None:
        return default
    text = str(value).strip()
    return text if text else default

