# Mock Cloud 后端迁移交接说明

本文档面向后端同学，说明当前本地 Mock Cloud 的作用、接口契约和后续迁移到真实云端的建议。

## 1. 当前 Mock Cloud 的作用

当前 `mock_cloud/` 是一个本地 FastAPI 假云端，用于在真实后端完成前验证完整业务闭环：

```text
设备上传 -> AI 分析 -> 告警生成 -> 转为工单 -> Web 展示
```

它不是最终生产后端，但接口形态可以作为后端实现参考。后续可由 Spring Boot、FastAPI 或 Node.js 实现同样接口。

## 2. 后续需要实现的接口

### GET /

功能：返回服务状态。

响应示例：

```json
{
  "service": "Yizhi Mock Cloud",
  "status": "running",
  "ai_runtime": "mock mode"
}
```

### GET /api/dashboard/summary

功能：返回社区大屏摘要。

响应示例：

```json
{
  "elder_count": 12,
  "high_risk_count": 2,
  "pending_alarm_count": 3,
  "offline_device_count": 1
}
```

### GET /api/elders

功能：返回老人列表。

响应示例：

```json
{
  "items": [
    {
      "elder_id": "E001",
      "elder_name": "张爷爷",
      "age": 82,
      "device_id": "ESP32S3-E001",
      "device_status": "online"
    }
  ],
  "count": 1
}
```

### POST /api/device/upload

功能：接收 ESP32-S3 上传的健康数据，并调用 AI 健康分析。

请求示例：

```json
{
  "elder_id": "E001",
  "heart_rate": 112,
  "spo2": 91,
  "temperature": 37.4,
  "activity_status": "长时间静止",
  "fall_status": "疑似跌倒",
  "location": "客厅",
  "duration": "35秒未起身"
}
```

响应示例：

```json
{
  "message": "设备数据上传成功",
  "health_data": {
    "record_id": "H0001",
    "elder_id": "E001",
    "elder_name": "张爷爷"
  },
  "ai_analysis": {
    "risk_level": "高风险",
    "need_alarm": true,
    "need_work_order": true,
    "work_order_type": "紧急巡检"
  },
  "alarm": {
    "alarm_id": "A0001",
    "status": "pending"
  }
}
```

### GET /api/health/latest/{elder_id}

功能：返回某个老人最新健康数据。

### GET /api/alarms

功能：返回告警列表。

### POST /api/alarms/{alarm_id}/to-work-order

功能：社区管理员将告警转为工单。

响应示例：

```json
{
  "message": "告警已转为工单",
  "work_order": {
    "work_order_id": "WO0001",
    "alarm_id": "A0001",
    "type": "紧急巡检",
    "status": "pending"
  }
}
```

### GET /api/work-orders

功能：返回工单列表。

### POST /api/ai/health-analysis

功能：直接调用 AI 健康分析模块。后端可把该接口部署为内部服务，也可在设备上传流程中同步调用。

### POST /api/ai/chat/quick

功能：本地规则即时回复，不依赖大模型。适合老人端秒级安抚和紧急关键词拦截。

### POST /api/ai/chat/deep

功能：云端深度回复，可调用 DeepSeek V4 Pro 或后续替换为其他大模型。

### POST /api/ai/chat

功能：兼容接口，同时返回 quick_reply 和 deep_reply。

### POST /api/ai/rag-query

功能：养老知识库 RAG 问答。

### POST /api/ai/vision-analysis

功能：视觉分析占位接口。当前 mock，后续接入真正 VLM。

### POST /api/demo/reset、POST /api/demo/seed、GET /api/demo/status

功能：仅用于比赛演示或测试环境。生产环境可以不开放。

## 3. 建议进入 MySQL 的数据

- 老人档案：`elder_id`、姓名、年龄、性别、住址、联系人、联系方式、风险标签。
- 设备档案：设备 ID、设备类型、绑定老人、在线状态、最后上报时间。
- 健康记录：心率、血氧、体温、活动状态、跌倒状态、位置、上传时间、AI 分析结果。
- 告警记录：告警 ID、老人 ID、风险等级、风险原因、状态、创建时间、处理时间、关联工单。
- 工单记录：工单 ID、告警 ID、类型、状态、优先级、处理人、处理结果、创建时间、完成时间。
- 对话记录：老人 ID、用户输入、quick_reply、deep_reply、意图、告警标记、时间。
- RAG 查询日志：问题、命中知识、回答、模型来源、耗时。

## 4. 建议进入 OSS 的文件

- 摄像头抓拍图片。
- 门口访客图片。
- 跌倒检测相关视频片段。
- 语音输入原始音频。
- 需要长期归档的报告附件。

数据库只保存 OSS 文件地址、文件类型、关联老人、关联告警和上传时间。

## 5. AI 模块和后端业务模块边界

AI 模块负责：

- 健康风险分析。
- 陪伴对话意图识别和回复。
- RAG 知识库问答。
- VLM 图片分析结果生成。
- 输出固定 JSON 和解释性文本。

后端业务模块负责：

- 用户、老人、设备、权限管理。
- 接收设备数据并持久化。
- 调用 AI 服务。
- 告警生命周期管理。
- 工单派发、流转和归档。
- APP、Web 大屏接口聚合。
- 文件上传到 OSS。

## 6. 从本地 FastAPI 迁移到阿里云 ECS

推荐路径：

1. 在 ECS 安装 Python 运行环境，部署当前 AI 模块。
2. 使用 `uvicorn` 或 `gunicorn + uvicorn worker` 运行 FastAPI 服务。
3. 使用 Nginx 做反向代理和 HTTPS。
4. 在 ECS 或容器环境配置 `DEEPSEEK_API_KEY`，不要写入代码仓库。
5. 后端服务通过 HTTP 调用 AI 服务接口。
6. MySQL、Redis、OSS 等由业务后端统一管理。
7. 使用 systemd、Supervisor 或容器编排保障服务重启。

## 7. 和 Web 大屏/APP 对接

Web 大屏建议调用：

- `/api/dashboard/summary`
- `/api/elders`
- `/api/alarms`
- `/api/work-orders`
- `/api/health/latest/{elder_id}`

亲属 APP 建议调用：

- 老人最新状态接口。
- 告警通知接口。
- 陪伴对话接口。
- 工单处理进度接口。

设备端建议调用：

- `/api/device/upload`
- 后续可增加批量上传、心跳、设备状态更新接口。

## 8. 落地建议

真实后端实现时，可以完全保留当前 JSON 字段命名，减少前端和 AI 模块联调成本。Mock Cloud 的价值是先把业务闭环跑通，后端同学只需要把内存数据替换为 MySQL、把本地文件替换为 OSS、把测试接口按环境隔离即可。

