# Python AI 服务云端部署说明

本文档用于把 `yizhi-ai-module` 部署为同一台 ECS 上的 Python AI 服务，由 Java 后端通过内网本机地址调用。

## 1. 部署目标架构

```text
Java 后端：http://127.0.0.1:8080
Python AI 服务：http://127.0.0.1:8000
Java 通过 AI_SERVICE_BASE_URL=http://127.0.0.1:8000 调用 Python AI
```

Python AI 服务只监听 `127.0.0.1:8000`，不直接暴露公网。公网入口仍由 Java 后端提供。

## 2. 上传 release 包到服务器

建议目录：

```text
/var/www/yizhi-ai-module/
```

示例：

```bash
sudo mkdir -p /var/www/yizhi-ai-module
sudo chown -R $USER:$USER /var/www/yizhi-ai-module
unzip yizhi-ai-module-cloud-release.zip -d /var/www/yizhi-ai-module
cd /var/www/yizhi-ai-module
```

## 3. 安装依赖

```bash
pip install -r requirements.txt
```

如果服务器使用虚拟环境：

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 4. 配置环境变量

可以使用 `.env` 文件：

```bash
DEEPSEEK_API_KEY=请在服务器上填写
DEEPSEEK_BASE_URL=https://api.deepseek.com
DEEPSEEK_MODEL=deepseek-v4-pro
MOCK_MODE=auto
TIMEOUT_SECONDS=60
```

也可以使用系统环境变量：

```bash
export DEEPSEEK_API_KEY="请在服务器上填写"
export DEEPSEEK_BASE_URL="https://api.deepseek.com"
export DEEPSEEK_MODEL="deepseek-v4-pro"
export MOCK_MODE="auto"
```

不要把真实 API Key 写入 Git、README、日志或公开截图。

## 5. 启动 Python AI 服务

直接启动：

```bash
python -m mock_cloud.app --host 127.0.0.1 --port 8000
```

后台启动：

```bash
bash scripts/cloud/start_ai_service.sh
```

日志输出到：

```text
logs/ai_service.log
```

停止服务：

```bash
bash scripts/cloud/stop_ai_service.sh
```

## 6. 测试 Python AI 服务

```bash
bash scripts/cloud/check_ai_service.sh
```

手动检查：

```bash
curl http://127.0.0.1:8000/api/health
```

预期返回：

```json
{
  "code": 200,
  "message": "success",
  "data": {
    "service": "yizhi-python-ai",
    "status": "running",
    "mode": "mock",
    "deepseek_available": false
  }
}
```

## 7. 配置 Java 后端调用 Python AI

重启 Java 后端前设置：

```bash
export AI_SERVICE_BASE_URL=http://127.0.0.1:8000
```

或使用启动参数：

```bash
--ai.service.base-url=http://127.0.0.1:8000
```

Java 后端应通过 `AI_SERVICE_BASE_URL` 转发 `/api/ai/*` 请求到 Python AI 服务。

## 8. 验证 Java 后端是否成功转发

公网访问 Java 后端：

```text
GET http://120.27.129.78:8080/api/ai/service-status
POST http://120.27.129.78:8080/api/ai/health-analysis
POST http://120.27.129.78:8080/api/ai/rag-query
```

运行脚本：

```bash
python scripts/check_cloud_ai_integration.py
```

预期 `source` 变为：

```text
python_ai_service
```

如果仍显示 `java_*`，说明 Java 后端还在 fallback/mock，未成功转发到 Python AI 服务。

## 9. systemd 开机自启

模板文件：

```text
deploy/yizhi-ai.service.example
```

安装示例：

```bash
sudo cp deploy/yizhi-ai.service.example /etc/systemd/system/yizhi-ai.service
sudo systemctl daemon-reload
sudo systemctl enable yizhi-ai
sudo systemctl start yizhi-ai
sudo systemctl status yizhi-ai
```

如果使用虚拟环境，请把模板中的 `ExecStart` 改为虚拟环境 Python 路径，例如：

```text
ExecStart=/var/www/yizhi-ai-module/.venv/bin/python -m mock_cloud.app --host 127.0.0.1 --port 8000
```

## 10. 故障处理

### Python AI 服务没启动

检查：

```bash
ps aux | grep mock_cloud.app
tail -n 100 logs/ai_service.log
curl http://127.0.0.1:8000/api/health
```

### DeepSeek API Key 没配置

现象：`/api/health` 中 `mode=mock` 或 `deepseek_available=false`。

处理：检查 `.env` 或系统环境变量中的 `DEEPSEEK_API_KEY`，重启 Python AI 服务。

### Java 仍然走 fallback

现象：`scripts/check_cloud_ai_integration.py` 显示 `source=java_*`。

处理：

1. 确认 Java 后端配置了 `AI_SERVICE_BASE_URL=http://127.0.0.1:8000`。
2. 确认 Java 进程已重启。
3. 确认 ECS 本机能访问 `curl http://127.0.0.1:8000/api/health`。

### 8000 端口被占用

检查：

```bash
ss -ltnp | grep :8000
```

如果已有旧 Python AI 服务，先停止：

```bash
bash scripts/cloud/stop_ai_service.sh
```

### 服务器无法访问 DeepSeek API

处理：

1. 检查服务器外网访问。
2. 检查安全组和 DNS。
3. 临时设置 `MOCK_MODE=true` 保证 Java 后端仍可调用 Python AI mock 能力。

