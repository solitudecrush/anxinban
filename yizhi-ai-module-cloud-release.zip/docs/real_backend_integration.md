# 真实云端后端联调说明

本文档说明“颐智云护·银龄智守”Web Demo 如何在本地 Mock Cloud 与真实 Spring Boot 后端之间切换，以及当前真实后端的能力边界。

## 1. 真实后端 baseUrl

```text
http://120.27.129.78:8080
```

本地 Mock Cloud baseUrl：

```text
http://127.0.0.1:8000
```

## 2. 本地 Mock Cloud 与真实后端的区别

本地 Mock Cloud：

- 运行在本机，默认地址为 `http://127.0.0.1:8000`。
- 适合比赛主演示，稳定、快速、不依赖外网。
- AI 模块可走本地 mock 或 DeepSeek V4 Pro。
- 支持 `/api/demo/reset` 和 `/api/demo/seed`，便于反复演示。

真实云端后端：

- 运行在云服务器，地址为 `http://120.27.129.78:8080`。
- 用于展示后端部署、MySQL 真实读写和业务闭环。
- 设备上传、告警、工单等业务数据会写入真实后端数据库。
- 当前 AI 接口仍主要是 Java mock/fallback，不等同于完整 DeepSeek AI 能力。

## 3. 已兼容接口

经 `python scripts\check_real_backend.py` 复验，以下接口已可用于联调：

- `GET /api/health`
- `GET /api/dashboard/summary`
- `POST /api/device/upload`
- `GET /api/alarms`
- `POST /api/alarms/{alarm_id}/to-work-order`
- `GET /api/work-orders`
- `POST /api/ai/health-analysis`
- `POST /api/ai/chat/quick`
- `POST /api/ai/chat/deep`
- `POST /api/ai/rag-query`
- `POST /api/ai/vision-analysis`

## 4. 真实数据库读写功能

真实后端已支持以下业务闭环：

```text
设备上传 -> 健康数据保存 -> 生成告警 -> 告警列表查询 -> 转为工单 -> 工单列表查询
```

这些能力可以用于展示服务器部署和数据库闭环。

## 5. AI 接口当前状态

当前真实后端 AI 接口仍为 Java mock/fallback：

- `health-analysis`：`java_rule_fallback`
- `chat/deep`：`java_mock_deep`
- `rag-query`：`java_mock_rag`
- `vision-analysis`：`java_mock_vision`

这些接口可用于验证字段兼容和前端联调，但不能作为完整 DeepSeek AI 能力证明。完整 DeepSeek AI 演示建议继续使用本地 Mock Cloud。

## 6. 比赛建议

- 主演示使用本地 Mock Cloud：稳定、快速、可重置数据，并可展示完整 AI 能力。
- 真实云端后端作为辅助展示：用于证明后端已部署到服务器，并能完成真实数据库读写闭环。
- 如果评委追问云端能力，可以切换 Web Demo API 地址到真实云端后端，展示 `/api/health`、设备上传、告警和工单。

## 7. Web Demo 如何切换 API 地址

打开：

```text
web_demo/index.html
```

在顶部“后端连接状态”区域选择：

- 本地 Mock Cloud：`http://127.0.0.1:8000`
- 真实云端后端：`http://120.27.129.78:8080`
- 自定义 API 地址

点击“应用 API 地址”后，再点击“检测服务”。选择会保存到 `localStorage`，刷新页面后仍保持上次选择。

真实云端后端不支持 `/api/demo/reset` 和 `/api/demo/seed`，页面会禁用“重置演示数据 / 载入演示数据”。需要生成演示数据时，使用“场景演示按钮”中的设备上传场景。

## 8. 真实后端不可用时如何切回本地 Mock Cloud

1. 启动本地 Mock Cloud：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\windows\start_mock_cloud_mock.ps1
```

2. 在 Web Demo 顶部选择“本地 Mock Cloud”。
3. 点击“应用 API 地址”。
4. 点击“检测服务”。
5. 如果仍失败，打开 `http://127.0.0.1:8000/docs` 确认本地服务是否启动。

