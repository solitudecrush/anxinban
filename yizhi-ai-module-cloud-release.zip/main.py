# -*- coding: utf-8 -*-
"""Simple command-line menu for the local AI module demos."""

from __future__ import annotations

import json
from pathlib import Path

from src.config import describe_runtime_mode
from src.elder_chat import chat_with_elder
from src.health_analysis import analyze_health_data
from src.rag_engine import generate_rag_answer
from src.vision_analysis import analyze_vision


PROJECT_ROOT = Path(__file__).resolve().parent


def _print_json(value: dict) -> None:
    print(json.dumps(value, ensure_ascii=False, indent=2))


def run_health_demo() -> None:
    cases = json.loads((PROJECT_ROOT / "data" / "demo_health_cases.json").read_text(encoding="utf-8"))
    for index, case in enumerate(cases, start=1):
        print(f"\n=== 健康风险分析案例 {index}: {case.get('elder_name', case.get('elder_id'))} ===")
        _print_json(analyze_health_data(case))


def run_chat_demo() -> None:
    dialogues = json.loads((PROJECT_ROOT / "data" / "demo_dialogues.json").read_text(encoding="utf-8"))
    for index, item in enumerate(dialogues, start=1):
        print(f"\n=== 陪伴对话案例 {index}: {item.get('message')} ===")
        _print_json(chat_with_elder(item))


def run_rag_demo() -> None:
    queries = [
        "血氧 91 怎么办？",
        "老人摔倒后怎么办？",
        "睡眠不好可以怎么缓解？",
        "智能门锁异常怎么办？",
        "社区工单什么时候生成？",
    ]
    for index, query in enumerate(queries, start=1):
        print(f"\n=== RAG 查询 {index}: {query} ===")
        _print_json(generate_rag_answer(query))


def run_vision_demo() -> None:
    tasks = [
        {"elder_id": "E001", "image_path": "demo_images/fall_demo.jpg", "task": "fall_detection", "extra_query": ""},
        {"elder_id": "E001", "image_path": "demo_images/cup_demo.jpg", "task": "object_search", "extra_query": "找水杯"},
        {"elder_id": "E002", "image_path": "demo_images/door_demo.jpg", "task": "door_visitor", "extra_query": "门口是谁"},
        {"elder_id": "E003", "image_path": "demo_images/living_room.jpg", "task": "scene_description", "extra_query": ""},
    ]
    for index, item in enumerate(tasks, start=1):
        print(f"\n=== 视觉分析案例 {index}: {item['task']} ===")
        _print_json(analyze_vision(item))


def main() -> None:
    while True:
        print("\n颐智云护·银龄智守 AI 模块原型")
        print(f"运行模式：{describe_runtime_mode()}")
        print("1. 健康风险分析 demo")
        print("2. 陪伴对话 demo")
        print("3. RAG 知识库 demo")
        print("4. 视觉分析 demo")
        print("5. 退出")
        choice = input("请选择功能编号：").strip()

        if choice == "1":
            run_health_demo()
        elif choice == "2":
            run_chat_demo()
        elif choice == "3":
            run_rag_demo()
        elif choice == "4":
            run_vision_demo()
        elif choice == "5":
            print("已退出。")
            break
        else:
            print("请输入 1-5 之间的编号。")


if __name__ == "__main__":
    main()
