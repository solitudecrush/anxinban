# 颐智云护·银龄智守 AI 模块原型

这是“颐智云护·银龄智守”智慧养老项目的本地 AI 模块原型，用于在 Windows 本地演示云端 AI 能力。当前版本不依赖云服务器，支持 mock 模式和 DeepSeek V4 Pro 文本大模型模式。

## 项目作用

- 健康数据 AI 风险分析：根据 ESP32-S3 传感器数据、跌倒状态、活动状态输出固定 JSON。
- 陪伴对话与适老化回复：对老人语音文本进行意图识别、安抚回复和告警判断。
- RAG 养老知识库原型：用轻量关键词检索返回相关养老知识并生成回答。
- 摄像头/VLM 图片分析接口占位：当前返回 mock 结果，后续可接 Qwen-VL、Qwen2.5-VL 或其他多模态模型。
- 固定 JSON 输出：方便后续对接亲属 APP、社区 Web 大屏和后端接口。

## 目录结构

```text
.
├── README.md
├── requirements.txt
├── .env.example
├── main.py
├── prompts/
├── data/
├── src/
├── scripts/
└── docs/
```

## 安装依赖

```powershell
pip install -r requirements.txt
```

依赖保持轻量：

- `requests`：调用 DeepSeek OpenAI-compatible Chat Completions API。
- `python-dotenv`：可选读取本地 `.env`，不是必须。

## Windows 环境变量检查

代码通过以下方式读取 Windows 用户环境变量：

```python
os.getenv("DEEPSEEK_API_KEY")
```

PowerShell 检查：

```powershell
echo $env:DEEPSEEK_API_KEY
```

CMD 检查：

```cmd
echo %DEEPSEEK_API_KEY%
```

如果刚刚新增了 Windows 用户环境变量，需要重新打开 PowerShell / CMD / Codex 终端，让新的环境变量对当前 Python 进程生效。

如果只是想临时在当前 PowerShell 会话设置：

```powershell
$env:DEEPSEEK_API_KEY="sk-xxxxxx"
```

这只是临时设置。你已经通过 Windows 用户变量配置了 `DEEPSEEK_API_KEY` 时，一般不需要再设置。

## 环境变量

参考 `.env.example`：

```env
DEEPSEEK_API_KEY=
DEEPSEEK_BASE_URL=https://api.deepseek.com
DEEPSEEK_MODEL=deepseek-v4-pro
MOCK_MODE=auto
TIMEOUT_SECONDS=60
```

`MOCK_MODE` 支持：

- `auto`：有 `DEEPSEEK_API_KEY` 时调用真实 API，没有时自动 mock。
- `true`：强制 mock，不请求网络。
- `false`：强制真实 API；如果当前进程读不到 `DEEPSEEK_API_KEY`，会返回清晰错误提示。

不要把真实 API Key 写入代码、README、配置文件或日志。

## 运行 demo

主菜单：

```powershell
python main.py
```

单独运行：

```powershell
python scripts\run_health_demo.py
python scripts\run_chat_demo.py
python scripts\run_rag_demo.py
python scripts\run_vision_demo.py
```

强制 mock 测试：

```powershell
$env:MOCK_MODE="true"
python scripts\run_health_demo.py
```

使用 DeepSeek V4 Pro 真实 API：

```powershell
$env:MOCK_MODE="auto"
python scripts\run_chat_demo.py
```

只要当前 Python 进程能读取到 `DEEPSEEK_API_KEY`，`auto` 模式会调用真实 DeepSeek API。若读不到 key，会自动进入 mock 模式，保证本地演示可运行。

## 模块说明

- `src/config.py`：读取环境变量，支持 Windows 用户变量和可选 `.env`。
- `src/llm_client.py`：封装 `DeepSeekClient.chat_completion(messages, temperature=0.2)`。
- `src/json_utils.py`：从模型返回中容错提取 JSON。
- `src/health_analysis.py`：规则优先的健康风险分析，LLM 用于优化解释。
- `src/elder_chat.py`：规则优先的陪伴对话，紧急关键词不完全依赖大模型。
- `src/rag_engine.py`：关键词检索版轻量 RAG。
- `src/vision_analysis.py`：VLM 接口占位和 mock 返回。

## 和 Web 大屏对接

本地模块输出均为 JSON，可由后端直接包装为 HTTP 接口：

- 健康分析结果展示为风险等级、异常原因、家属通知、社区处理建议。
- 高风险或中风险结果可自动进入“待处理告警”和“工单列表”。
- RAG 回答可作为社区管理员辅助处置说明。
- VLM mock 结果可先用于大屏联调，后续替换为真实视觉模型结果。

接口草案见 `docs/ai_interface_spec.md`。

## 后续接入云端后端

迁移到云端时，建议保持当前模块函数的输入输出 JSON 不变：

- `analyze_health_data(payload)` 对应 `POST /api/ai/health-analysis`
- `chat_with_elder(payload)` 对应 `POST /api/ai/chat`
- `generate_rag_answer(query)` 对应 `POST /api/ai/rag-query`
- `analyze_vision(payload)` 对应 `POST /api/ai/vision-analysis`

后端可使用 FastAPI、Flask、Spring Boot 或 Node.js 调用这些 Python 模块，也可以把模块改造成独立微服务。

## vision 模块为什么是 mock

当前模型 `deepseek-v4-pro` 在本原型中作为文本大模型使用，主要负责文本推理、健康建议、告警解释和陪伴对话。图片分析需要真正支持图片输入的多模态 VLM，例如 Qwen-VL、Qwen2.5-VL 或其他视觉模型。

因此 `src/vision_analysis.py` 当前只做接口占位和 mock 输出，不直接调用 `deepseek-v4-pro` 看图。

## RAG 后续升级

当前 RAG 是轻量原型，使用关键词和简单相似度检索，方便本地演示。后续可替换为：

- Chroma
- FAISS
- Qdrant
- pgvector
- 云端向量数据库

## 本地假云端演示

### 为什么要做 mock cloud

真实云端后端暂未完成时，`mock_cloud/` 用 FastAPI 在本地模拟云端服务，串起设备上传、AI 健康分析、告警生成、社区转工单、Web 大屏联调等完整闭环。它不依赖真实云服务器，DeepSeek API Key 仍然通过 Windows 用户环境变量 `DEEPSEEK_API_KEY` 读取；如果当前进程读不到 Key，会按原有配置进入 mock 模式。

### 启动服务

```powershell
python -m mock_cloud.app
```

也可以使用 uvicorn：

```powershell
uvicorn mock_cloud.app:app --reload --host 127.0.0.1 --port 8000
```

如果 Windows 提示找不到 `uvicorn` 命令，可以使用：

```powershell
python -m uvicorn mock_cloud.app:app --reload --host 127.0.0.1 --port 8000
```

### 打开 Swagger 文档

服务启动后访问：

```text
http://127.0.0.1:8000/docs
```

### 运行设备上传模拟

```powershell
python scripts\mock_device_upload.py
```

脚本会依次上传正常数据、血氧偏低数据、疑似跌倒高风险数据，其中高风险数据会自动生成告警。

### 一键演示完整闭环

```powershell
python scripts\demo_full_flow.py
```

流程包括：发送疑似跌倒数据、获取 AI 分析、查询告警、将待处理告警转为工单、查询工单列表。

### 打开 Web Demo

启动 mock cloud 后，直接用浏览器打开：

```text
web_demo/index.html
```

页面会访问 `http://127.0.0.1:8000`，可演示服务状态、大屏摘要、设备上传、陪伴对话、RAG 问答、告警列表和工单列表。

### 后续迁移到阿里云 ECS

迁移到阿里云 ECS 时，可以先把 `mock_cloud/app.py` 作为临时 FastAPI 服务部署，后续再逐步替换为正式后端：

- 将 `fake_db.py` 的内存列表替换为 MySQL、PostgreSQL 或云数据库。
- 将本地启动命令改为 systemd、Docker 或云效流水线托管。
- 将 `127.0.0.1:8000` 替换为 ECS 内网地址、反向代理域名或 API 网关地址。
- 将告警推送、短信、亲属 APP 通知接入正式消息服务。
- 将 vision mock 替换为真实 VLM 服务，例如 Qwen-VL 或 Qwen2.5-VL。

### 后端同学可直接参考实现的接口

- `GET /`
- `GET /api/dashboard/summary`
- `GET /api/elders`
- `POST /api/device/upload`
- `GET /api/health/latest/{elder_id}`
- `GET /api/alarms`
- `POST /api/alarms/{alarm_id}/to-work-order`
- `GET /api/work-orders`
- `POST /api/ai/health-analysis`
- `POST /api/ai/chat`
- `POST /api/ai/rag-query`
- `POST /api/ai/vision-analysis`

## 陪伴对话两阶段响应设计

普通情感陪伴不应完全等待云端大模型。老人说话后如果等待数秒才有回应，体验会明显变差；遇到“救命、摔倒、喘不上气、胸口疼、头晕、叫人、打电话”等紧急表达时，也不能把第一响应完全交给云端模型。

### 本地 quick_reply 的作用

- 快速安抚：本地规则立即返回短句，例如“我在，请先坐下或保持不动，慢慢呼吸”。
- 紧急求助本地优先处理：风险关键词和异常健康指标会立即标记 `need_alarm`、`need_family_notify`。
- 降低比赛演示等待时间：前端可以先展示本地即时回复，再等待云端深度回复。

接口：

```text
POST /api/ai/chat/quick
```

### 云端 deep_reply 的作用

- 复杂语义理解：由 DeepSeek V4 Pro 或 mock deep reply 生成更完整的回复。
- 健康咨询：对“血氧 91 怎么办”“睡不着怎么办”等问题，可结合 RAG 知识库。
- RAG 知识增强：返回 `rag_used` 表示是否使用知识库。
- 个性化建议：给出更完整但不做确定医疗诊断的建议。

接口：

```text
POST /api/ai/chat/deep
```

兼容接口仍然保留：

```text
POST /api/ai/chat
```

它会组合 quick 和 deep，返回 `quick_reply`、`deep_reply`、`quick_latency_seconds`、`deep_latency_seconds` 和 `mode=combined`。

### DeepSeek API 检测

运行：

```powershell
python scripts\check_deepseek_api.py
```

脚本会读取 Windows 用户环境变量 `DEEPSEEK_API_KEY`，但不会打印完整 Key。如果当前进程读不到 Key，会提示用 PowerShell/CMD 检查并重新打开终端。

### 延迟测试

启动 mock cloud：

```powershell
python -m mock_cloud.app
```

另开一个终端运行：

```powershell
python scripts\latency_benchmark.py
```

脚本会测试 `chat/quick`、`chat/deep`、`health-analysis`、`rag-query` 的平均、最小、最大耗时。

升级时建议保留 `retrieve_knowledge(query, top_k=3)` 和 `generate_rag_answer(query)` 的函数签名，减少前后端改动。

## 比赛演示快速启动

当前项目已经完成本地闭环：

```text
设备上传 -> AI分析 -> 告警 -> 工单 -> Web展示
```

### Windows PowerShell 启动方式

Mock 模式启动，适合无网络、稳定演示或不消耗 DeepSeek API：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\windows\start_mock_cloud_mock.ps1
```

DeepSeek 模式启动，适合展示真实 DeepSeek V4 Pro 能力：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\windows\start_mock_cloud_deepseek.ps1
```

检查当前 PowerShell 进程和 Windows User env 是否能读取 Key：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\windows\check_deepseek_env.ps1
```

这些脚本不会打印完整 `DEEPSEEK_API_KEY`。如果 Windows User env 有 Key 但当前进程没有，`start_mock_cloud_deepseek.ps1` 会把 User env 注入当前 PowerShell 进程后再启动服务。

### Mock 模式和 DeepSeek 模式区别

- Mock 模式：`MOCK_MODE=true`，不请求真实网络，演示最稳定。
- DeepSeek 模式：`MOCK_MODE=false`，会调用真实 DeepSeek V4 Pro，回复更自然，但受网络和模型延迟影响。
- 自动模式：`MOCK_MODE=auto`，有 Key 时尝试真实 API，没有 Key 时自动 mock。

### Web Demo 演示说明

启动 mock cloud 后，用浏览器打开：

```text
web_demo/index.html
```

页面包含：

- 后端连接检测、AI 运行模式、DeepSeek 可用状态。
- 重置演示数据、载入演示数据、刷新摘要、刷新告警/工单。
- 老人总数、高风险人数、待处理告警、工单数量、离线设备数量。
- 正常数据、血氧偏低、疑似跌倒高风险、两阶段陪伴对话、RAG 问答、Vision mock 场景。
- 告警转工单按钮和最近一次接口 JSON 输出。

如果页面提示后端未启动，请先运行：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\windows\start_mock_cloud_mock.ps1
```

或：

```powershell
powershell -ExecutionPolicy Bypass -File scripts\windows\start_mock_cloud_deepseek.ps1
```

### 演示数据接口

比赛演示新增以下接口：

- `POST /api/demo/reset`：清空运行时健康数据、告警和工单，恢复初始老人列表。
- `POST /api/demo/seed`：写入正常老人、血氧偏低、疑似跌倒高风险和设备离线告警演示数据。
- `GET /api/demo/status`：返回健康记录数、告警数、工单数、运行模式和 DeepSeek 可用状态。

### 文档入口

- [docs/demo_runbook.md](docs/demo_runbook.md)：比赛现场演示步骤、讲解话术和故障处理。
- [docs/backend_handoff.md](docs/backend_handoff.md)：后端同学迁移真实云端时的接口、数据表和部署边界说明。

## Release 版交付与验收

比赛前建议先运行最终验收：

```powershell
python scripts\final_acceptance_check.py
```

验收脚本会检查 Python 编译、核心 demo、文档、Web Demo、Windows 启动脚本和安全扫描。如果 mock cloud 未启动，只会给 WARN，不会作为阻塞失败。

运行敏感信息安全扫描：

```powershell
python scripts\security_scan.py
```

该脚本会扫描 `.py`、`.md`、`.txt`、`.json`、`.html`、`.ps1`、`.bat` 和 `.env.example`，检查是否误写入疑似 `sk-*` API Key。扫描结果不会输出完整密钥，只会输出脱敏片段。

打包 Release：

```powershell
python scripts\package_release.py
```

打包产物：

```text
release/yizhi-ai-module-release.zip
```

打包前会先执行安全扫描。如果发现明显完整 Key，会停止打包。

### Windows BAT 一键脚本

不会使用 PowerShell 的队友可以直接双击或在 CMD 中运行：

```cmd
scripts\windows_bat\start_mock_cloud_mock.bat
scripts\windows_bat\start_mock_cloud_deepseek.bat
scripts\windows_bat\open_web_demo.bat
scripts\windows_bat\run_self_check.bat
scripts\windows_bat\run_latency_benchmark.bat
```

- `start_mock_cloud_mock.bat`：稳定 mock 模式，不消耗 DeepSeek API。
- `start_mock_cloud_deepseek.bat`：真实 DeepSeek 模式，需要当前 CMD 能读取 `DEEPSEEK_API_KEY`。
- `open_web_demo.bat`：打开 `web_demo/index.html`，需先启动 mock cloud。
- `run_self_check.bat`：运行核心自检。
- `run_latency_benchmark.bat`：运行延迟统计。

交付给队友或打包备份时，不要包含 `.env`，不要把真实 API Key 写入 README、文档、脚本、日志或压缩包。

答辩讲解稿见 [docs/ai_defense_script.md](docs/ai_defense_script.md)。

## 真实后端兼容性验收

用于验证后端同学部署的 Spring Boot 后端是否兼容当前 Mock Cloud 的接口格式。

当前真实后端 baseUrl：

```text
http://120.27.129.78:8080
```

运行：

```powershell
python scripts\check_real_backend.py
```

该脚本会按设备上传、告警、转工单、工单列表和 AI 接口顺序测试真实后端，并输出 PASS / WARN / FAIL 报告。它不依赖本地 Mock Cloud 是否启动，也不依赖 DeepSeek API。

## 真实云端后端联调

真实后端地址：

```text
http://120.27.129.78:8080
```

运行兼容性验收：

```powershell
python scripts\check_real_backend.py
```

Web Demo 顶部已支持 API 地址切换，可选择：

- 本地 Mock Cloud：`http://127.0.0.1:8000`
- 真实云端后端：`http://120.27.129.78:8080`
- 自定义 API 地址

选择“真实云端后端”后，页面会优先检测 `/api/health`，并将设备上传、告警列表、告警转工单、工单列表和 `/api/ai/*` 请求发送到真实后端。

注意：当前真实后端 AI 接口仍是 Java mock/fallback，不等同于完整 DeepSeek AI 能力。比赛主演示仍建议使用本地 Mock Cloud；真实云端后端适合作为服务器部署和 MySQL 真实业务闭环的辅助展示。

更多说明见 [docs/real_backend_integration.md](docs/real_backend_integration.md)。

## Python AI 云端部署包

用于部署到同一台 ECS，让 Java 后端通过本机地址调用 Python AI 服务：

```text
AI_SERVICE_BASE_URL=http://127.0.0.1:8000
```

本地启动命令：

```powershell
python -m mock_cloud.app --host 127.0.0.1 --port 8000
```

Linux/ECS 后台启动脚本：

```bash
bash scripts/cloud/start_ai_service.sh
```

健康检查：

```text
GET http://127.0.0.1:8000/api/health
```

云端部署文档见 [docs/python_ai_cloud_deploy.md](docs/python_ai_cloud_deploy.md)。

检查 Java 后端是否已转发到 Python AI：

```powershell
python scripts\check_cloud_ai_integration.py
```

生成云端部署包：

```powershell
python scripts\package_cloud_release.py
```

产物：

```text
release/yizhi-ai-module-cloud-release.zip
```
