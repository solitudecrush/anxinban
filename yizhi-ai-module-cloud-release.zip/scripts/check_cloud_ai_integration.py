# -*- coding: utf-8 -*-
"""Check whether the public Java backend is forwarding AI calls to Python AI."""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Tuple

import requests


BASE_URL = "http://120.27.129.78:8080"
TIMEOUT_SECONDS = 10

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except AttributeError:
    pass


@dataclass
class Result:
    endpoint: str
    status: str
    message: str


def payload_of(data: Any) -> Any:
    if isinstance(data, dict) and "data" in data:
        return data.get("data")
    return data


def recursive_find(data: Any, keys: Iterable[str]) -> Any:
    wanted = {key.lower() for key in keys}
    if isinstance(data, dict):
        for key, value in data.items():
            if key.lower() in wanted:
                return value
        for value in data.values():
            found = recursive_find(value, keys)
            if found is not None:
                return found
    elif isinstance(data, list):
        for item in data:
            found = recursive_find(item, keys)
            if found is not None:
                return found
    return None


def request_json(method: str, path: str, payload: Optional[Dict[str, Any]] = None) -> Tuple[Optional[int], Optional[Any], str]:
    try:
        response = requests.request(
            method,
            f"{BASE_URL}{path}",
            json=payload,
            timeout=TIMEOUT_SECONDS,
            headers={"Accept": "application/json"},
        )
    except requests.RequestException as exc:
        return None, None, str(exc)

    try:
        body = response.json()
    except ValueError:
        return response.status_code, None, response.text[:200]
    if response.status_code != 200:
        return response.status_code, body, json.dumps(body, ensure_ascii=False)[:300]
    return response.status_code, body, ""


def classify_source(source: Any) -> Tuple[str, str]:
    source_text = str(source or "")
    if source_text == "python_ai_service":
        return "PASS", "source=python_ai_service"
    if source_text.startswith("java_"):
        return "WARN", f"source={source_text}，仍在 Java fallback/mock"
    if not source_text:
        return "WARN", "未返回 source，无法确认是否已转发 Python AI"
    return "WARN", f"source={source_text}，不是 python_ai_service"


def check_endpoint(method: str, path: str, payload: Optional[Dict[str, Any]] = None) -> Result:
    http_status, body, error = request_json(method, path, payload)
    if http_status != 200 or body is None:
        return Result(path, "FAIL", f"HTTP={http_status}, {error or '请求失败'}")

    source = recursive_find(payload_of(body), ["source"])
    status, message = classify_source(source)
    return Result(path, status, message)


def main() -> int:
    checks = [
        ("GET", "/api/ai/service-status", None),
        (
            "POST",
            "/api/ai/health-analysis",
            {
                "elder_id": "cloud_check_001",
                "recent_health": {"heart_rate": 112, "spo2": 91, "temperature": 37.4},
            },
        ),
        (
            "POST",
            "/api/ai/chat/quick",
            {
                "elder_id": "cloud_check_001",
                "message": "我有点喘不上气",
                "recent_health": {"heart_rate": 112, "spo2": 91, "temperature": 37.4},
            },
        ),
        (
            "POST",
            "/api/ai/chat/deep",
            {"elder_id": "cloud_check_001", "message": "我今天心情不太好"},
        ),
        ("POST", "/api/ai/rag-query", {"query": "老年人如何预防跌倒？", "top_k": 3}),
        (
            "POST",
            "/api/ai/vision-analysis",
            {"elder_id": "cloud_check_001", "analysis_type": "fall_detection"},
        ),
    ]

    results: List[Result] = [check_endpoint(method, path, payload) for method, path, payload in checks]
    pass_count = sum(1 for item in results if item.status == "PASS")
    warn_count = sum(1 for item in results if item.status == "WARN")
    fail_count = sum(1 for item in results if item.status == "FAIL")

    print("# Python AI 云端集成检查报告\n")
    print(f"baseUrl: {BASE_URL}\n")
    print("| 接口 | 状态 | 说明 |")
    print("| -- | -- | -- |")
    for item in results:
        print(f"| {item.endpoint} | {item.status} | {item.message} |")

    print("\n## 汇总\n")
    print(f"PASS / WARN / FAIL: {pass_count} / {warn_count} / {fail_count}")
    if fail_count:
        print("当前 Java 后端调用 Python AI 服务存在失败项。")
    elif warn_count:
        print("当前 Java 后端尚未完全切换到 Python AI 服务，部分接口仍在 fallback/mock。")
    else:
        print("当前 Java 后端已成功调用 Python AI 服务。")

    return 1 if fail_count else 0


if __name__ == "__main__":
    raise SystemExit(main())
