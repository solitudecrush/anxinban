#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
LOG_DIR="${PROJECT_DIR}/logs"
PID_FILE="${LOG_DIR}/ai_service.pid"
HOST="${AI_SERVICE_HOST:-127.0.0.1}"
PORT="${AI_SERVICE_PORT:-8000}"

cd "${PROJECT_DIR}"
mkdir -p "${LOG_DIR}"

if [ -f "${PROJECT_DIR}/.env" ]; then
  set -a
  # shellcheck disable=SC1091
  . "${PROJECT_DIR}/.env"
  set +a
fi

if [ -f "${PID_FILE}" ]; then
  OLD_PID="$(cat "${PID_FILE}")"
  if [ -n "${OLD_PID}" ] && ps -p "${OLD_PID}" >/dev/null 2>&1; then
    echo "AI service already running, pid=${OLD_PID}"
    exit 0
  fi
fi

echo "Starting Yizhi Python AI service on ${HOST}:${PORT}"
nohup python -m mock_cloud.app --host "${HOST}" --port "${PORT}" > "${LOG_DIR}/ai_service.log" 2>&1 &
echo "$!" > "${PID_FILE}"
echo "Started, pid=$(cat "${PID_FILE}")"
echo "Log: ${LOG_DIR}/ai_service.log"
