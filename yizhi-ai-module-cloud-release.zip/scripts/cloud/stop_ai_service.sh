#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/../.." && pwd)"
PID_FILE="${PROJECT_DIR}/logs/ai_service.pid"

stop_pid() {
  local pid="$1"
  if [ -z "${pid}" ] || ! ps -p "${pid}" >/dev/null 2>&1; then
    return 0
  fi
  local args
  args="$(ps -p "${pid}" -o args= || true)"
  if echo "${args}" | grep -q "mock_cloud.app"; then
    echo "Stopping AI service pid=${pid}"
    kill "${pid}"
  else
    echo "Refusing to stop pid=${pid}; command is not mock_cloud.app"
  fi
}

if [ -f "${PID_FILE}" ]; then
  stop_pid "$(cat "${PID_FILE}")"
  rm -f "${PID_FILE}"
else
  pids="$(pgrep -f "python .* -m mock_cloud.app" || true)"
  if [ -z "${pids}" ]; then
    echo "No Yizhi Python AI service process found."
    exit 0
  fi
  for pid in ${pids}; do
    stop_pid "${pid}"
  done
fi

echo "Stop command completed."
