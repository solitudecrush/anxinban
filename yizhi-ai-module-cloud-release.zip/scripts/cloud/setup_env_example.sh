#!/usr/bin/env bash

# Example only. Do not commit or print a real API key.
export DEEPSEEK_API_KEY="请在服务器上填写"
export DEEPSEEK_BASE_URL="https://api.deepseek.com"
export DEEPSEEK_MODEL="deepseek-v4-pro"
export MOCK_MODE="auto"
export TIMEOUT_SECONDS="60"

echo "示例环境变量已写出。请在服务器真实环境中替换 DEEPSEEK_API_KEY。"
