#!/usr/bin/env bash
set -euo pipefail

python - <<'PY'
import json
import sys
import urllib.error
import urllib.request

BASE_URL = "http://127.0.0.1:8000"
TIMEOUT = 10


def request(method, path, payload=None):
    data = None
    headers = {"Accept": "application/json"}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(BASE_URL + path, data=data, method=method, headers=headers)
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        return resp.status, json.loads(resp.read().decode("utf-8"))


checks = []

try:
    status, body = request("GET", "/api/health")
    ok = status == 200 and body.get("code") == 200
    checks.append(("GET /api/health", ok, body))
except Exception as exc:
    checks.append(("GET /api/health", False, str(exc)))

try:
    payload = {
        "elder_id": "cloud_check_001",
        "recent_health": {"heart_rate": 112, "spo2": 91, "temperature": 37.4},
    }
    status, body = request("POST", "/api/ai/health-analysis", payload)
    checks.append(("POST /api/ai/health-analysis", status == 200 and bool(body.get("risk_level")), body))
except Exception as exc:
    checks.append(("POST /api/ai/health-analysis", False, str(exc)))

try:
    payload = {"query": "老人摔倒后怎么办？", "top_k": 3}
    status, body = request("POST", "/api/ai/rag-query", payload)
    checks.append(("POST /api/ai/rag-query", status == 200 and bool(body.get("answer")), body))
except Exception as exc:
    checks.append(("POST /api/ai/rag-query", False, str(exc)))

failed = False
for name, ok, detail in checks:
    if ok:
        print(f"[PASS] {name}")
    else:
        failed = True
        print(f"[FAIL] {name}: {detail}")

sys.exit(1 if failed else 0)
PY
