# -*- coding: utf-8 -*-
"""Local mock cloud backend for the Yizhi AI module prototype."""

