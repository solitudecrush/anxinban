# -*- coding: utf-8 -*-
"""In-memory fake database for the local mock cloud service."""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime
from typing import Any, Dict, List, Optional


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


ELDERS: List[Dict[str, Any]] = [
    {
        "elder_id": "E001",
        "elder_name": "张爷爷",
        "age": 82,
        "gender": "男",
        "address": "1 号楼 302",
        "primary_contact": "张女士",
        "phone_masked": "138****0001",
        "device_id": "ESP32S3-E001",
        "device_status": "online",
        "risk_tag": "重点关注",
    },
    {
        "elder_id": "E002",
        "elder_name": "李奶奶",
        "age": 78,
        "gender": "女",
        "address": "2 号楼 1102",
        "primary_contact": "李先生",
        "phone_masked": "139****0002",
        "device_id": "ESP32S3-E002",
        "device_status": "online",
        "risk_tag": "血氧关注",
    },
    {
        "elder_id": "E003",
        "elder_name": "王爷爷",
        "age": 75,
        "gender": "男",
        "address": "3 号楼 601",
        "primary_contact": "王女士",
        "phone_masked": "137****0003",
        "device_id": "ESP32S3-E003",
        "device_status": "online",
        "risk_tag": "心率关注",
    },
    {
        "elder_id": "E004",
        "elder_name": "陈奶奶",
        "age": 84,
        "gender": "女",
        "address": "5 号楼 204",
        "primary_contact": "陈先生",
        "phone_masked": "136****0004",
        "device_id": "ESP32S3-E004",
        "device_status": "online",
        "risk_tag": "夜间关注",
    },
    {
        "elder_id": "E005",
        "elder_name": "赵爷爷",
        "age": 80,
        "gender": "男",
        "address": "6 号楼 808",
        "primary_contact": "赵女士",
        "phone_masked": "135****0005",
        "device_id": "ESP32S3-E005",
        "device_status": "online",
        "risk_tag": "正常",
    },
    {
        "elder_id": "E006",
        "elder_name": "周奶奶",
        "age": 77,
        "gender": "女",
        "address": "7 号楼 301",
        "primary_contact": "周先生",
        "phone_masked": "134****0006",
        "device_id": "ESP32S3-E006",
        "device_status": "online",
        "risk_tag": "正常",
    },
    {
        "elder_id": "E007",
        "elder_name": "吴爷爷",
        "age": 86,
        "gender": "男",
        "address": "8 号楼 1201",
        "primary_contact": "吴女士",
        "phone_masked": "133****0007",
        "device_id": "ESP32S3-E007",
        "device_status": "online",
        "risk_tag": "重点关注",
    },
    {
        "elder_id": "E008",
        "elder_name": "郑奶奶",
        "age": 79,
        "gender": "女",
        "address": "9 号楼 502",
        "primary_contact": "郑先生",
        "phone_masked": "132****0008",
        "device_id": "ESP32S3-E008",
        "device_status": "offline",
        "risk_tag": "设备离线",
    },
    {
        "elder_id": "E009",
        "elder_name": "孙爷爷",
        "age": 73,
        "gender": "男",
        "address": "10 号楼 602",
        "primary_contact": "孙女士",
        "phone_masked": "131****0009",
        "device_id": "ESP32S3-E009",
        "device_status": "online",
        "risk_tag": "正常",
    },
    {
        "elder_id": "E010",
        "elder_name": "马奶奶",
        "age": 81,
        "gender": "女",
        "address": "11 号楼 905",
        "primary_contact": "马先生",
        "phone_masked": "130****0010",
        "device_id": "ESP32S3-E010",
        "device_status": "online",
        "risk_tag": "睡眠关注",
    },
    {
        "elder_id": "E011",
        "elder_name": "朱爷爷",
        "age": 76,
        "gender": "男",
        "address": "12 号楼 705",
        "primary_contact": "朱女士",
        "phone_masked": "159****0011",
        "device_id": "ESP32S3-E011",
        "device_status": "online",
        "risk_tag": "正常",
    },
    {
        "elder_id": "E012",
        "elder_name": "胡奶奶",
        "age": 83,
        "gender": "女",
        "address": "13 号楼 403",
        "primary_contact": "胡先生",
        "phone_masked": "158****0012",
        "device_id": "ESP32S3-E012",
        "device_status": "online",
        "risk_tag": "正常",
    },
]

_INITIAL_ELDERS = deepcopy(ELDERS)

HEALTH_RECORDS: List[Dict[str, Any]] = []
ALARMS: List[Dict[str, Any]] = []
WORK_ORDERS: List[Dict[str, Any]] = []

_health_seq = 1
_alarm_seq = 1
_work_order_seq = 1


def reset_runtime_data() -> Dict[str, str]:
    """Clear runtime demo data and restore the initial elder list."""

    global ELDERS, _health_seq, _alarm_seq, _work_order_seq

    ELDERS = deepcopy(_INITIAL_ELDERS)
    HEALTH_RECORDS.clear()
    ALARMS.clear()
    WORK_ORDERS.clear()
    _health_seq = 1
    _alarm_seq = 1
    _work_order_seq = 1
    return {"message": "演示数据已重置"}


def runtime_counts() -> Dict[str, int]:
    """Return current in-memory demo data counts."""

    return {
        "health_records": len(HEALTH_RECORDS),
        "alarms": len(ALARMS),
        "work_orders": len(WORK_ORDERS),
    }


def list_elders() -> List[Dict[str, Any]]:
    return deepcopy(ELDERS)


def get_elder(elder_id: str) -> Optional[Dict[str, Any]]:
    for elder in ELDERS:
        if elder["elder_id"] == elder_id:
            return deepcopy(elder)
    return None


def dashboard_summary() -> Dict[str, int]:
    pending_alarms = [alarm for alarm in ALARMS if alarm["status"] == "pending"]
    high_risk_elders = {
        alarm["elder_id"]
        for alarm in pending_alarms
        if alarm.get("risk_level") == "高风险"
    }
    offline_devices = [
        elder for elder in ELDERS if elder.get("device_status") == "offline"
    ]
    return {
        "elder_count": len(ELDERS),
        "high_risk_count": len(high_risk_elders),
        "pending_alarm_count": len(pending_alarms),
        "offline_device_count": len(offline_devices),
    }


def save_health_record(
    upload: Dict[str, Any], analysis: Dict[str, Any]
) -> Dict[str, Any]:
    global _health_seq

    elder = get_elder(upload["elder_id"]) or {}
    record = {
        "record_id": f"H{_health_seq:04d}",
        "elder_id": upload["elder_id"],
        "elder_name": upload.get("elder_name") or elder.get("elder_name", "未知老人"),
        "heart_rate": upload.get("heart_rate"),
        "spo2": upload.get("spo2"),
        "temperature": upload.get("temperature"),
        "activity_status": upload.get("activity_status"),
        "fall_status": upload.get("fall_status"),
        "location": upload.get("location"),
        "duration": upload.get("duration", "实时上传"),
        "uploaded_at": _now(),
        "ai_analysis": deepcopy(analysis),
    }
    _health_seq += 1
    HEALTH_RECORDS.insert(0, record)
    return deepcopy(record)


def latest_health(elder_id: str) -> Optional[Dict[str, Any]]:
    for record in HEALTH_RECORDS:
        if record["elder_id"] == elder_id:
            return deepcopy(record)
    return None


def create_alarm(record: Dict[str, Any], analysis: Dict[str, Any]) -> Dict[str, Any]:
    global _alarm_seq

    alarm = {
        "alarm_id": f"A{_alarm_seq:04d}",
        "elder_id": record["elder_id"],
        "elder_name": record["elder_name"],
        "record_id": record["record_id"],
        "risk_level": analysis.get("risk_level", "高风险"),
        "risk_reason": analysis.get("risk_reason", ""),
        "location": record.get("location", ""),
        "status": "pending",
        "created_at": _now(),
        "family_notice": analysis.get("family_notice", ""),
        "community_suggestion": analysis.get("community_suggestion", ""),
        "work_order_type": analysis.get("work_order_type", "紧急巡检"),
        "ai_analysis": deepcopy(analysis),
    }
    _alarm_seq += 1
    ALARMS.insert(0, alarm)
    return deepcopy(alarm)


def create_manual_alarm(
    elder_id: str,
    risk_level: str,
    risk_reason: str,
    alarm_type: str,
    location: str,
) -> Dict[str, Any]:
    """Create a non-health alarm, such as a device offline or door-lock event."""

    global _alarm_seq

    elder = get_elder(elder_id) or {}
    alarm = {
        "alarm_id": f"A{_alarm_seq:04d}",
        "elder_id": elder_id,
        "elder_name": elder.get("elder_name", "未知老人"),
        "record_id": "",
        "risk_level": risk_level,
        "risk_reason": risk_reason,
        "location": location,
        "status": "pending",
        "created_at": _now(),
        "family_notice": f"{elder.get('elder_name', '老人')}出现{alarm_type}，建议确认现场情况。",
        "community_suggestion": "建议社区值班人员核实设备状态，必要时派发设备检查工单。",
        "work_order_type": "设备检查",
        "alarm_type": alarm_type,
        "ai_analysis": {
            "risk_level": risk_level,
            "risk_reason": risk_reason,
            "need_alarm": True,
            "need_work_order": True,
            "work_order_type": "设备检查",
        },
    }
    _alarm_seq += 1
    ALARMS.insert(0, alarm)
    return deepcopy(alarm)


def seed_demo_data() -> Dict[str, int]:
    """Seed deterministic competition demo data."""

    normal_upload = {
        "elder_id": "E005",
        "elder_name": "赵爷爷",
        "heart_rate": 78,
        "spo2": 97,
        "temperature": 36.5,
        "activity_status": "正常活动",
        "fall_status": "未跌倒",
        "location": "卧室",
        "duration": "实时上传",
    }
    low_spo2_upload = {
        "elder_id": "E002",
        "elder_name": "李奶奶",
        "heart_rate": 88,
        "spo2": 90,
        "temperature": 36.8,
        "activity_status": "坐姿休息",
        "fall_status": "未跌倒",
        "location": "客厅",
        "duration": "实时上传",
    }
    fall_upload = {
        "elder_id": "E001",
        "elder_name": "张爷爷",
        "heart_rate": 116,
        "spo2": 90,
        "temperature": 37.3,
        "activity_status": "长时间静止",
        "fall_status": "疑似跌倒",
        "location": "客厅",
        "duration": "42秒未起身",
    }

    normal_analysis = {
        "elder_id": "E005",
        "risk_level": "正常",
        "risk_reason": "生命体征处于正常范围，未检测到跌倒或长时间异常静止。",
        "elder_reply": "赵爷爷，当前状态看起来正常，您可以继续安心休息。",
        "family_notice": "赵爷爷当前健康数据正常，暂无异常告警。",
        "community_suggestion": "无需生成工单，继续常规监测。",
        "need_alarm": False,
        "need_work_order": False,
        "work_order_type": "无需工单",
    }
    low_spo2_analysis = {
        "elder_id": "E002",
        "risk_level": "中风险",
        "risk_reason": "血氧为90%，低于92%的关注阈值，暂未检测到跌倒。",
        "elder_reply": "李奶奶，请先坐下休息，慢慢呼吸，我会帮您持续关注。",
        "family_notice": "李奶奶血氧偏低，建议家属关注并电话确认老人状态。",
        "community_suggestion": "建议生成健康关注工单，社区人员可电话回访或上门确认。",
        "need_alarm": True,
        "need_work_order": True,
        "work_order_type": "健康关注",
    }
    fall_analysis = {
        "elder_id": "E001",
        "risk_level": "高风险",
        "risk_reason": "检测到疑似跌倒、长时间静止，同时血氧偏低且心率偏高。",
        "elder_reply": "张爷爷，请先不要急着起身，我马上帮您联系家属和社区人员。",
        "family_notice": "张爷爷在客厅疑似跌倒，伴随血氧偏低和心率偏高，请尽快确认。",
        "community_suggestion": "建议立即生成紧急巡检工单，安排社区人员上门确认老人状态。",
        "need_alarm": True,
        "need_work_order": True,
        "work_order_type": "紧急巡检",
    }

    before_health = len(HEALTH_RECORDS)
    before_alarms = len(ALARMS)
    for upload, analysis in [
        (normal_upload, normal_analysis),
        (low_spo2_upload, low_spo2_analysis),
        (fall_upload, fall_analysis),
    ]:
        record = save_health_record(upload, analysis)
        if analysis.get("need_alarm") is True:
            create_alarm(record, analysis)

    create_manual_alarm(
        elder_id="E008",
        risk_level="中风险",
        risk_reason="设备连续离线，可能影响实时监测和紧急告警。",
        alarm_type="设备离线",
        location="9 号楼 502",
    )

    return {
        "health_records_created": len(HEALTH_RECORDS) - before_health,
        "alarms_created": len(ALARMS) - before_alarms,
        "health_records": len(HEALTH_RECORDS),
        "alarms": len(ALARMS),
        "work_orders": len(WORK_ORDERS),
    }


def list_alarms() -> List[Dict[str, Any]]:
    return deepcopy(ALARMS)


def get_alarm(alarm_id: str) -> Optional[Dict[str, Any]]:
    for alarm in ALARMS:
        if alarm["alarm_id"] == alarm_id:
            return alarm
    return None


def alarm_to_work_order(alarm_id: str) -> Optional[Dict[str, Any]]:
    global _work_order_seq

    alarm = get_alarm(alarm_id)
    if alarm is None:
        return None

    if alarm.get("work_order_id"):
        for work_order in WORK_ORDERS:
            if work_order["work_order_id"] == alarm["work_order_id"]:
                return deepcopy(work_order)

    work_order = {
        "work_order_id": f"WO{_work_order_seq:04d}",
        "alarm_id": alarm["alarm_id"],
        "elder_id": alarm["elder_id"],
        "elder_name": alarm["elder_name"],
        "type": alarm.get("work_order_type") or "紧急巡检",
        "status": "pending",
        "priority": "high" if alarm.get("risk_level") == "高风险" else "normal",
        "location": alarm.get("location", ""),
        "description": alarm.get("risk_reason", ""),
        "suggestion": alarm.get("community_suggestion", ""),
        "created_at": _now(),
        "assignee": "社区值班员",
    }
    _work_order_seq += 1
    WORK_ORDERS.insert(0, work_order)
    alarm["status"] = "converted"
    alarm["work_order_id"] = work_order["work_order_id"]
    alarm["converted_at"] = _now()
    return deepcopy(work_order)


def list_work_orders() -> List[Dict[str, Any]]:
    return deepcopy(WORK_ORDERS)
