# -*- coding: utf-8 -*-
"""FastAPI mock cloud backend for local full-flow demos."""

from __future__ import annotations

import argparse
from time import perf_counter
from typing import Any, Dict

import uvicorn
from fastapi import Body, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from mock_cloud import fake_db
from mock_cloud.schemas import (
    ChatRequest,
    DeviceUploadRequest,
    RagQueryRequest,
)
from src.config import describe_runtime_mode
from src.config import get_settings
from src.elder_chat import chat_with_elder
from src.health_analysis import analyze_health_data
from src.rag_engine import generate_rag_answer
from src.vision_analysis import analyze_vision


app = FastAPI(
    title="Yizhi Mock Cloud",
    description="Local fake cloud backend for the Yizhi elderly-care AI module.",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _model_to_dict(model: Any) -> Dict[str, Any]:
    """Support both Pydantic v1 and v2."""

    if hasattr(model, "model_dump"):
        return model.model_dump()
    return model.dict()


def _normalize_health_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Accept both device-upload shape and Java-forwarded recent_health shape."""

    data = dict(payload)
    recent_health = data.get("recent_health") or {}
    if isinstance(recent_health, dict):
        for key in ["heart_rate", "spo2", "temperature"]:
            if data.get(key) is None and recent_health.get(key) is not None:
                data[key] = recent_health.get(key)

    data.setdefault("elder_id", "UNKNOWN")
    data.setdefault("heart_rate", 0)
    data.setdefault("spo2", 0)
    data.setdefault("temperature", 36.5)
    data.setdefault("activity_status", "未知")
    data.setdefault("fall_status", "未检测到跌倒")
    data.setdefault("location", "未知位置")
    data.setdefault("duration", "实时上传")
    return data


def _normalize_vision_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Accept both task and analysis_type for future Java backend forwarding."""

    data = dict(payload)
    if not data.get("task") and data.get("analysis_type"):
        data["task"] = data.get("analysis_type")
    data.setdefault("image_path", "")
    data.setdefault("task", "scene_description")
    data.setdefault("extra_query", "")
    return data


def _quick_chat_reply(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Generate an instant local reply without any model call."""

    message = str(payload.get("message") or "").replace(" ", "")
    recent_health = payload.get("recent_health") or {}
    heart_rate = float(recent_health.get("heart_rate") or 0)
    spo2 = float(recent_health.get("spo2") or 0)
    temperature = float(recent_health.get("temperature") or 0)
    risky_health = (0 < spo2 < 92) or heart_rate > 110 or temperature >= 37.5

    emergency_keywords = [
        "救命",
        "摔倒",
        "跌倒",
        "喘不上气",
        "胸口疼",
        "胸闷",
        "不舒服",
        "头晕",
        "打电话",
        "叫人",
        "呼吸困难",
    ]
    if any(keyword in message for keyword in emergency_keywords) or risky_health:
        return {
            "quick_reply": "我在，请先坐下或保持不动，慢慢呼吸。我马上帮您联系家属和社区人员。",
            "intent": "紧急求助",
            "need_alarm": True,
            "need_family_notify": True,
            "suggested_action": "立即联系家属或社区人员，并持续关注老人状态。",
        }

    if any(keyword in message for keyword in ["水杯", "眼镜", "钥匙", "遥控器", "在哪里", "找不到"]):
        return {
            "quick_reply": "好的，我帮您找一找。请您先坐稳，不要着急走动。",
            "intent": "物品查找",
            "need_alarm": False,
            "need_family_notify": False,
            "suggested_action": "调用摄像头或物品定位能力辅助查找。",
        }

    if any(keyword in message for keyword in ["门口", "门锁", "访客", "开门"]):
        return {
            "quick_reply": "我来帮您确认门口情况，请先不要开门。",
            "intent": "设备控制",
            "need_alarm": False,
            "need_family_notify": False,
            "suggested_action": "调用门口摄像头或门锁事件核实。",
        }

    if any(keyword in message for keyword in ["睡不着", "吃药", "血氧", "心率", "体温", "身体"]):
        return {
            "quick_reply": "我听到了。您先放松休息一下，如果一直不舒服，我会建议联系家人。",
            "intent": "健康咨询",
            "need_alarm": False,
            "need_family_notify": False,
            "suggested_action": "提供非诊断性质建议，并观察后续状态。",
        }

    if any(keyword in message for keyword in ["孤单", "孤独", "难过", "没人说话", "陪我"]):
        return {
            "quick_reply": "我在呢，您慢慢说，我陪您聊一会儿。",
            "intent": "普通陪伴",
            "need_alarm": False,
            "need_family_notify": False,
            "suggested_action": "继续陪伴交流",
        }

    return {
        "quick_reply": "我在，您慢慢说。",
        "intent": "普通陪伴",
        "need_alarm": False,
        "need_family_notify": False,
        "suggested_action": "继续陪伴对话，必要时转给家属。",
    }


def _quick_chat_response(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Return the local-rule quick response with latency."""

    started_at = perf_counter()
    quick = _quick_chat_reply(payload)
    return {
        "elder_id": payload.get("elder_id", "UNKNOWN"),
        "intent": quick["intent"],
        "quick_reply": quick["quick_reply"],
        "need_alarm": quick["need_alarm"],
        "need_family_notify": quick["need_family_notify"],
        "suggested_action": quick["suggested_action"],
        "source": "local_rule",
        "latency_seconds": round(perf_counter() - started_at, 4),
    }


def _should_use_rag_for_chat(message: str, intent: str) -> bool:
    """Use RAG for health and elderly-care knowledge questions."""

    compact = message.replace(" ", "")
    rag_keywords = [
        "血氧",
        "心率",
        "体温",
        "睡不着",
        "睡眠",
        "摔倒",
        "跌倒",
        "门锁",
        "吃药",
        "用药",
        "怎么办",
        "怎么缓解",
    ]
    return intent == "健康咨询" or any(keyword in compact for keyword in rag_keywords)


def _mock_deep_reply(payload: Dict[str, Any], quick: Dict[str, Any]) -> str:
    """Build a deterministic deep-reply fallback for mock mode."""

    intent = quick.get("intent")
    if quick.get("need_alarm") is True:
        return "我已经记录到紧急信号。请您先保持安全姿势，系统会建议联系家属和社区人员确认情况。"
    if intent == "健康咨询":
        return "可以先休息一下，观察身体变化。这个建议不能替代医生诊断，如果持续不舒服，请联系家属或医生。"
    if intent == "物品查找":
        return "我会帮您一起找。请您先坐稳，后续可以结合摄像头或物品定位能力确认位置。"
    if intent == "设备控制":
        return "我会帮您确认设备或门口情况。在确认安全前，请先不要开门或操作设备。"
    return "我在呢，您慢慢说，我陪您聊一会儿。如果您愿意，我也可以帮您联系家属或播放一段舒缓音乐。"


def _deep_chat_response(payload: Dict[str, Any], quick: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Return the cloud/deep response with optional RAG support."""

    started_at = perf_counter()
    quick_result = quick or _quick_chat_response(payload)
    message = str(payload.get("message") or "")
    settings = get_settings()
    source = settings.deepseek_model if (not settings.should_use_mock and settings.has_api_key) else "mock"
    rag_used = False

    try:
        if _should_use_rag_for_chat(message, quick_result["intent"]):
            rag = generate_rag_answer(message, top_k=2)
            retrieved = rag.get("retrieved_knowledge") or []
            if retrieved:
                rag_used = True
                deep_reply = rag.get("answer") or _mock_deep_reply(payload, quick_result)
            else:
                deep_reply = _mock_deep_reply(payload, quick_result)
        else:
            deep = chat_with_elder(payload)
            deep_reply = deep.get("reply") or _mock_deep_reply(payload, quick_result)

        if quick_result["need_alarm"] is True and "联系" not in deep_reply:
            deep_reply = "云端已收到紧急信号，建议立即通知家属和社区人员确认老人状态。"
    except Exception:
        source = "mock"
        deep_reply = _mock_deep_reply(payload, quick_result)

    return {
        "elder_id": payload.get("elder_id", "UNKNOWN"),
        "intent": quick_result["intent"],
        "deep_reply": deep_reply,
        "source": source,
        "rag_used": rag_used,
        "latency_seconds": round(perf_counter() - started_at, 4),
    }


@app.get("/")
def service_status() -> Dict[str, str]:
    return {
        "service": "Yizhi Mock Cloud",
        "status": "running",
        "ai_runtime": describe_runtime_mode(),
    }


@app.get("/api/health")
def ai_service_health() -> Dict[str, Any]:
    settings = get_settings()
    mode = "mock" if settings.should_use_mock else "deepseek"
    return {
        "code": 200,
        "message": "success",
        "data": {
            "service": "yizhi-python-ai",
            "status": "running",
            "mode": mode,
            "deepseek_available": bool(settings.has_api_key and not settings.should_use_mock),
        },
    }


@app.get("/api/dashboard/summary")
def get_dashboard_summary() -> Dict[str, int]:
    return fake_db.dashboard_summary()


@app.get("/api/elders")
def get_elders() -> Dict[str, Any]:
    elders = fake_db.list_elders()
    return {"items": elders, "count": len(elders)}


@app.post("/api/demo/reset")
def reset_demo_data() -> Dict[str, str]:
    return fake_db.reset_runtime_data()


@app.post("/api/demo/seed")
def seed_demo_data() -> Dict[str, Any]:
    result = fake_db.seed_demo_data()
    return {
        "message": "演示数据已载入",
        **result,
    }


@app.get("/api/demo/status")
def get_demo_status() -> Dict[str, Any]:
    settings = get_settings()
    counts = fake_db.runtime_counts()
    return {
        **counts,
        "runtime": describe_runtime_mode(),
        "deepseek_available": bool(settings.has_api_key and not settings.should_use_mock),
    }


@app.post("/api/device/upload")
def upload_device_data(payload: DeviceUploadRequest) -> Dict[str, Any]:
    upload = _model_to_dict(payload)
    elder = fake_db.get_elder(upload["elder_id"]) or {}
    upload["elder_name"] = upload.get("elder_name") or elder.get("elder_name", "未知老人")

    ai_analysis = analyze_health_data(upload)
    record = fake_db.save_health_record(upload, ai_analysis)
    alarm = None
    if ai_analysis.get("need_alarm") is True:
        alarm = fake_db.create_alarm(record, ai_analysis)

    return {
        "message": "设备数据上传成功",
        "health_data": record,
        "ai_analysis": ai_analysis,
        "alarm": alarm,
    }


@app.get("/api/health/latest/{elder_id}")
def get_latest_health(elder_id: str) -> Dict[str, Any]:
    record = fake_db.latest_health(elder_id)
    if record is None:
        raise HTTPException(status_code=404, detail="未找到该老人的健康数据")
    return record


@app.get("/api/alarms")
def get_alarms() -> Dict[str, Any]:
    alarms = fake_db.list_alarms()
    return {"items": alarms, "count": len(alarms)}


@app.post("/api/alarms/{alarm_id}/to-work-order")
def convert_alarm_to_work_order(alarm_id: str) -> Dict[str, Any]:
    work_order = fake_db.alarm_to_work_order(alarm_id)
    if work_order is None:
        raise HTTPException(status_code=404, detail="告警不存在")
    return {"message": "告警已转为工单", "work_order": work_order}


@app.get("/api/work-orders")
def get_work_orders() -> Dict[str, Any]:
    work_orders = fake_db.list_work_orders()
    return {"items": work_orders, "count": len(work_orders)}


@app.post("/api/ai/health-analysis")
def ai_health_analysis(payload: Dict[str, Any] = Body(...)) -> Dict[str, Any]:
    data = _normalize_health_payload(payload)
    elder = fake_db.get_elder(data["elder_id"]) or {}
    data["elder_name"] = data.get("elder_name") or elder.get("elder_name", "未知老人")
    return analyze_health_data(data)


@app.post("/api/ai/chat")
def ai_chat(payload: ChatRequest) -> Dict[str, Any]:
    data = _model_to_dict(payload)
    quick = _quick_chat_response(data)
    deep = _deep_chat_response(data, quick)

    return {
        "quick_reply": quick["quick_reply"],
        "deep_reply": deep["deep_reply"],
        "intent": quick["intent"],
        "need_alarm": quick["need_alarm"],
        "need_family_notify": quick["need_family_notify"],
        "suggested_action": quick["suggested_action"],
        "quick_latency_seconds": quick["latency_seconds"],
        "deep_latency_seconds": deep["latency_seconds"],
        "mode": "combined",
    }


@app.post("/api/ai/chat/quick")
def ai_chat_quick(payload: ChatRequest) -> Dict[str, Any]:
    return _quick_chat_response(_model_to_dict(payload))


@app.post("/api/ai/chat/deep")
def ai_chat_deep(payload: ChatRequest) -> Dict[str, Any]:
    data = _model_to_dict(payload)
    quick = _quick_chat_response(data)
    return _deep_chat_response(data, quick)


@app.post("/api/ai/rag-query")
def ai_rag_query(payload: RagQueryRequest) -> Dict[str, Any]:
    return generate_rag_answer(payload.query, top_k=payload.top_k)


@app.post("/api/ai/vision-analysis")
def ai_vision_analysis(payload: Dict[str, Any] = Body(...)) -> Dict[str, Any]:
    return analyze_vision(_normalize_vision_payload(payload))


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Yizhi Python AI service.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8000, type=int)
    args = parser.parse_args()
    uvicorn.run("mock_cloud.app:app", host=args.host, port=args.port, reload=False)


if __name__ == "__main__":
    main()
