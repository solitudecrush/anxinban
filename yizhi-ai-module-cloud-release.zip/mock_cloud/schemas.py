# -*- coding: utf-8 -*-
"""Pydantic request schemas used by the mock cloud API."""

from __future__ import annotations

from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class DeviceUploadRequest(BaseModel):
    """Payload sent by a simulated ESP32-S3 device."""

    elder_id: str = Field(..., examples=["E001"])
    heart_rate: float = Field(..., examples=[112])
    spo2: float = Field(..., examples=[91])
    temperature: float = Field(..., examples=[37.4])
    activity_status: str = Field(..., examples=["长时间静止"])
    fall_status: str = Field(..., examples=["疑似跌倒"])
    location: str = Field(..., examples=["客厅"])
    duration: Optional[str] = Field(default="实时上传")
    elder_name: Optional[str] = None


class ChatRequest(BaseModel):
    """Payload for elder companionship chat."""

    elder_id: str = Field(..., examples=["E001"])
    message: str = Field(..., examples=["我有点喘不上气"])
    recent_health: Dict[str, Any] = Field(default_factory=dict)


class RagQueryRequest(BaseModel):
    """Payload for RAG knowledge-base query."""

    query: str = Field(..., examples=["老人摔倒后怎么办？"])
    top_k: int = Field(default=3, ge=1, le=10)


class VisionAnalysisRequest(BaseModel):
    """Payload for mock VLM analysis."""

    elder_id: str = Field(..., examples=["E001"])
    image_path: str = Field(default="", examples=["demo_images/fall_demo.jpg"])
    task: str = Field(default="scene_description", examples=["fall_detection"])
    extra_query: str = ""

